﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Threading;
using System.Management.Automation;
using System.Collections.ObjectModel;
using System.Management;
using System.Management.Instrumentation;
using System.Collections;

namespace New_WF_PIN_TEST_TOOL
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        bool File_All_Ready = false; //不用一直問File ready?
        int Columns_Report_Pro = -1; // + 3 剛好是 2 , report columns
        int Columns_Report_Home = -1;
        int Columns_Report;
        int Number_Actual_log = 1;
        bool Modified_Record_Request_Form = false;
        bool Modified_Record_Spec = false;
        string Jumpstart_file_name = "";
        int HP_Driver_start = 0; // HP rows
        int HP_Drivr_end = 0;
        int HP_app_start = 0;
        int HP_app_end = 0;
        int HP_hotfix = 0;
        int PP_Driver_start = 0;  // PP rows
        int PP_Drivr_end = 0;
        int PP_app_start = 0;
        int PP_app_end = 0;
        int PP_hotfix = 0;

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox_SKU_Harry.MaxLength = 3;
            textBox_SKU_Potter.MaxLength = 3;
            textBox_SKU_Peter.MaxLength = 3;
            textBox_SKU_Pan.MaxLength = 3;
            radioButton_SKU_Harry.Checked = true;
            radioButton_SKU_Peter.Checked = true;
            progressBar1.Visible = false;
            progressBar1.Maximum = 100;
            progressBar1.Value = 30;
            progressBar2.Visible = false;
            progressBar2.Maximum = 100;
            progressBar2.Value = 30;


            this.MaximizeBox = false;
            this.MinimizeBox = false;
            label_Msg_Actual_Log.Text = "";
            label_Msg_2.Text = "";
            radioButton_Actual_HP.Checked = Enabled;
            radioButton_Jumpstart_Enable.Checked = Enabled;
            radioButton_ResultCompare_HP.Checked = Enabled;

            // Setting Default
            Properties.Settings set = Properties.Settings.Default;

            //Jumpstart
            textBox_Jumpstart.Text = set.Jumpstart;

            //Harry Potter
            textBox_HP_D1.Text = set.HP_Driver_Start;
            textBox_HP_D2.Text = set.HP_Driver_End;
            textBox_HP_A1.Text = set.HP_APP_Start;
            textBox_HP_A2.Text = set.HP_APP_End;
            textBox_HP_Hotfix.Text = set.HP_Hotfix;

            //Peter Pan
            textBox_PP_D1.Text = set.PP_Driver_Start;
            textBox_PP_D2.Text = set.PP_Driver_End;
            textBox_PP_A1.Text = set.PP_APP_Start;
            textBox_PP_A2.Text = set.PP_APP_End;
            textBox_PP_Hotfix.Text = set.PP_Hotfix;

            // Unit Spec
            textBox_Spec_SheetName_Harry.Text = set.Harry_spec_sheet; //Harry
            textBox_Spec_rows_Harry_Start.Text = set.Harry_spec_rows_start;
            textBox_Spec_rows_Harry_End.Text = set.Harry_spec_rows_end;
            textBox_Spec_SheetName_Potter.Text = set.Potter_spec_sheet;//Potter
            textBox_Spec_rows_Potter_Start.Text = set.Potter_spec_rows_start;
            textBox_Spec_rows_Potter_End.Text = set.Potter_spec_rows_end;
            textBox_Spec_SheetName_Peter.Text = set.Peter_spec_sheet;//Peter
            textBox_Spec_rows_Peter_Start.Text = set.Peter_spec_rows_start;
            textBox_Spec_rows_Peter_End.Text = set.Peter_spec_rows_end;
            textBox_Spec_SheetName_Pan.Text = set.Pan_spec_sheet;//Pan
            textBox_Spec_rows_Pan_Start.Text = set.Pan_spec_rows_start;
            textBox_Spec_rows_Pan_End.Text = set.Pan_spec_rows_end;

            //======== 儲存暫存 如果不Save用============
            Modified_Record_Request_Form = false;
            Modified_Record_Spec = false;
            //tabControl1.SelectedTab = tabPage2;
        }

        private void button_Start_Test_Actual_log_Click(object sender, EventArgs e)
        {
            if (
            (radioButton_Actual_HP.Checked == true && radioButton_SKU_Harry.Checked == true && textBox_SKU_Harry.Text == "")
         || (radioButton_Actual_HP.Checked == true && radioButton_SKU_Potter.Checked == true && textBox_SKU_Potter.Text == "")
         || (radioButton_Actual_PP.Checked == true && radioButton_SKU_Peter.Checked == true && textBox_SKU_Peter.Text == "")
         || (radioButton_Actual_PP.Checked == true && radioButton_SKU_Pan.Checked == true && textBox_SKU_Pan.Text == "")
               )
            {
                MessageBox.Show("Invalid SKU number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            button_Start_Test_Actual_log.Visible = false;

            string get_version_Metro(string string_metro, string toFind_keyword)
            {

                int length = 0;
                int last_index = 0;
                int first_index = 0;
                string str_1 = string_metro;
                string toFind_1 = toFind_keyword;
                int index = str_1.IndexOf(toFind_1);
                //Console.WriteLine("{0}", index);
                last_index = index;
                while (true)
                {
                    index = index - 1;

                    if ((str_1.Substring(index, 1) == "_"))
                    {
                        first_index = index;
                        //Console.WriteLine("{0}", index);
                        break;
                    }
                }
                length = last_index - first_index - 1;
                //Console.WriteLine("length:{0}", length);
                string version = str_1.Substring(first_index + 1, length);
                //Console.WriteLine("version:{0}", version);
                return version;
            }

            void CopyDirectory(string SourceFolder, string DestinationFolder)
            {
                if (Directory.Exists(SourceFolder) == true)
                {
                    if (Directory.Exists(DestinationFolder) == false)
                    {
                        Directory.CreateDirectory(DestinationFolder);
                    }

                    DirectoryInfo srcDirectory = new DirectoryInfo(SourceFolder);

                    foreach (FileInfo fi in srcDirectory.GetFiles())
                    {
                        try
                        {
                            //FullName是檔案的完整路徑位址喔，Name才是檔案的名字
                            //Path.DirectorySeparatorChar是路徑裡的斜線啦
                            //最後面的true是是否覆蓋相同的檔案
                            File.Copy(fi.FullName, DestinationFolder + Path.DirectorySeparatorChar + fi.Name, true);
                        }
                        catch
                        {
                            MessageBox.Show("Failed in \"CopyDirectory\"");
                        }
                    }
                    foreach (DirectoryInfo di in srcDirectory.GetDirectories())
                    {
                        try
                        {
                            CopyDirectory(di.FullName, DestinationFolder + Path.DirectorySeparatorChar + di.Name);
                        }
                        catch
                        {
                            MessageBox.Show("Failed in \"CopyDirectory\"");
                        }
                    }
                }
            }



            if (radioButton_Jumpstart_Enable.Checked == Enabled)
            {
                // Enabled Jumpstart 
                Properties.Settings set = Properties.Settings.Default;
                Jumpstart_file_name = set.Jumpstart;

                //===============確認 Jumpstart file 是否存在==============++++++++
                string path_current_jumpstart = System.Environment.CurrentDirectory;
                string path_jumpstart_file = path_current_jumpstart + "\\" + Jumpstart_file_name;
                string source = path_jumpstart_file;
                string destinaiton = "C:\\temp";
                if ((Directory.Exists(path_jumpstart_file))) //Jumpstart file 是否存在
                {
                    // nothing
                }
                else
                {
                    MessageBox.Show(Jumpstart_file_name + " not found in this folder.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    button_Start_Test_Actual_log.Visible = true;
                    return;
                }
                //===============確認 Jumpstart file 是否存在==============++++++++

                progressBar1.Visible = true;

                //-------------------***Jumpstart***

                //----------------產生 JumpStart Files
                if ((Directory.Exists(destinaiton)))
                {
                    Directory.Delete(destinaiton, true);
                    Thread.Sleep(2000);
                }
                CopyDirectory(path_jumpstart_file, destinaiton); //如果存在 就產生 temp 資料夾
                Thread.Sleep(2000);
                //----------------產生 JumpStart Files

                label_Msg_Actual_Log.Text = "Jumpstart Check In Progress ...";

                // 執行 Jumpstart

                using (PowerShell PowerShellInstance = PowerShell.Create())
                {

                    string script = "Set-ExecutionPolicy -Scope Process -ExecutionPolicy Unrestricted; Get-ExecutionPolicy; CD C:\\temp; .\\OEMIPIC.PS1"; // the second command to know the ExecutionPolicy level
                    PowerShellInstance.AddScript(script);
                    var someResult = PowerShellInstance.Invoke();
                    someResult.ToList().ForEach(c => Console.WriteLine(c.ToString()));

                }
                //MessageBox.Show("JumpStart Done !");
                label_Msg_Actual_Log.Text = "Jumpstart Check Is Done";
                // 執行 Jumpstart
                Thread.Sleep(5000); //等待5秒
              //-------------------***Jumpstart***
            

            }
            else
            {
                label_Msg_Actual_Log.Text = "Jumpstart Check Is Disabled.";
                // Disabled Jumpstart 
            }

            progressBar1.Value = 70;

            //=================Get Actual Log ↓↓↓==================

            if (radioButton_Actual_HP.Checked == Enabled) // For Harry Potter
            {
                bool AZ_Bluetooh_check = false;
                bool GSD_Bluetooh_check = false;
                bool AZ_Wireless_check = false;
                bool GSD_Wireless_check = false;
                string OS_Pro_Home = "";
                label_Msg_Actual_Log.Text = "Actual log is being created ...";
                string path_current = System.Environment.CurrentDirectory;
                string path_actual_log = path_current + "\\Harry_Potter_Actual_" + Number_Actual_log + ".log";                
                string path_expected_log = path_current + "\\Harry_Potter_expected.log";
                
                
                while (File.Exists(path_actual_log)) // Actual.log already exist ?
                {
                    Number_Actual_log++;
                    path_actual_log = path_current + "\\Harry_Potter_Actual_" + Number_Actual_log + ".log";                    
                }



                //===============Jumpstart check ↓===============
                //  Jumpstart Check  
                bool found_jumpstart = false;
                string line_jumpstart = "";
                string result_in_jumpstart = "C:\\temp\\results_summary.txt";
                try
                {
                    // System.IO.StreamReader jumpstart_Content = new System.IO.StreamReader(result_in_jumpstart);
                    using (FileStream file = new FileStream(result_in_jumpstart, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite))
                    {
                        using (StreamReader jumpstart_Content = new StreamReader(file))
                        {
                            //Do your codes here 
                            while ((line_jumpstart = jumpstart_Content.ReadLine()) != null)
                            {

                                if (line_jumpstart.Contains("Jumpstart Compliance:")) // Software Title
                                {
                                    Console.WriteLine("{0}", line_jumpstart);
                                    found_jumpstart = true;
                                    if (line_jumpstart.Contains("PASSED"))
                                    {
                                        StreamWriter nexFile = File.AppendText(path_actual_log);
                                        nexFile.WriteLine("=PASSED= *Jumpstart*");
                                        nexFile.Close();
                                    }
                                    else if (line_jumpstart.Contains("FAILED"))
                                    {
                                        StreamWriter nexFile = File.AppendText(path_actual_log);
                                        nexFile.WriteLine("=FAILED= *Jumpstart*");
                                        nexFile.Close();
                                    }
                                    else
                                    {
                                        // NO Result found
                                        StreamWriter nexFile = File.AppendText(path_actual_log);                                        
                                        nexFile.WriteLine("=NO RESULT= *Jumpstart*");
                                        nexFile.Close();
                                    }

                                }

                                if (found_jumpstart)
                                {
                                    jumpstart_Content.Close();
                                    break;
                                }
                            }
                        }
                    }


                }
                catch
                {
                    MessageBox.Show("results_summary.txt Not Found", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    //NO Result found
                    StreamWriter nexFile = File.AppendText(path_actual_log);
                    nexFile.WriteLine("=results_summary.txt Not Found= *Jumpstart*");
                    nexFile.Close();

                }
                //===============Jumpstart check ↑===============

                //===========判斷 Home or Pro======================
                string os_PathString = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion";
                Microsoft.Win32.RegistryKey start_home_pro = Microsoft.Win32.Registry.LocalMachine;
                Microsoft.Win32.RegistryKey programName_home_pro = start_home_pro.OpenSubKey(os_PathString);
                string OS_version = (string)programName_home_pro.GetValue("ProductName");
                //Console.WriteLine("{0}", OS_version);
                if (OS_version.Contains("Windows 10 Pro"))
                {
                    OS_Pro_Home = "Pro 64";
                }
                else if (OS_version.Contains("Windows 10 Home"))
                {
                    OS_Pro_Home = "Home 64";
                }
                else
                {
                    MessageBox.Show("Not supported OS", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                //===========判斷 Home or Pro======================


                //============== ↓ Get version for Image ===========
                string short_path = @"C:\NexstGo.sav";
                string[] files = System.IO.Directory.GetFiles(short_path, "*.*", System.IO.SearchOption.TopDirectoryOnly);
                foreach (string full_path in files)
                {
                    string path_current_jumpstart = System.Environment.CurrentDirectory;
                    if (full_path.Contains("333N"))
                    {
                        string version = full_path.Remove(0, 15);
                        StreamWriter nexFile = File.AppendText(path_actual_log);
                        nexFile.WriteLine("={0}= *IMAGE*", version);
                        nexFile.Close();
                        if (version.Contains("333N001"))
                        {
                            StreamWriter nexFile_3 = File.AppendText(path_actual_log);
                            nexFile_3.WriteLine("=Harry= *PROJECT*");
                            nexFile_3.Close();
                        }
                        else if (version.Contains("333N002"))
                        {
                            StreamWriter nexFile_3 = File.AppendText(path_actual_log);
                            nexFile_3.WriteLine("=Potter= *PROJECT*");
                            nexFile_3.Close();
                        }
                        else if (version.Contains("333N003"))
                        {
                            StreamWriter nexFile_3 = File.AppendText(path_actual_log);
                            nexFile_3.WriteLine("=Peter= *PROJECT*");
                            nexFile_3.Close();
                        }
                        else if (version.Contains("333N004"))
                        {
                            StreamWriter nexFile_3 = File.AppendText(path_actual_log);
                            nexFile_3.WriteLine("=Pan= *PROJECT*");
                            nexFile_3.Close();
                        }
                    }
                }
                //============== ↑ Get version for Image ===========

                //=============== Tester name ===========
                string tester_path = "Volatile Environment";
                Microsoft.Win32.RegistryKey start_tester = Microsoft.Win32.Registry.CurrentUser;
                Microsoft.Win32.RegistryKey programName_tester = start_tester.OpenSubKey(tester_path);
                string Tester = (string)programName_tester.GetValue("USERNAME");
                //=============== Tester name =========== 

                //=============== Localization ===========
                string path_Locale_Name = ".DEFAULT\\Control Panel\\International";
                Microsoft.Win32.RegistryKey start_LocaleName = Microsoft.Win32.Registry.Users;
                Microsoft.Win32.RegistryKey programName_localename = start_LocaleName.OpenSubKey(path_Locale_Name);
                string localename = (string)programName_localename.GetValue("LocaleName");
                //=============== Localization ===========

                //---------------------------BIOS Version-----------------------------//
                string _BIOSversion = "";
                using (ManagementObjectSearcher mos = new ManagementObjectSearcher("SELECT * FROM Win32_BIOS"))
                using (ManagementObjectCollection mob = mos.Get())
                {
                    StringBuilder sb = new StringBuilder();
                    
                    foreach (ManagementObject mo in mob)
                    {
                        string[] BIOSVersions = (string[])mo["BIOSVersion"];
                        _BIOSversion = BIOSVersions[1];
                    }
                    //MessageBox.Show(_BIOSversion.ToString());
                }
                //---------------------------BIOS Version-----------------------------//

                
                //======== 寫值 Test name + Localization + BIOS version + OS 
                StreamWriter nexFile_4 = File.AppendText(path_actual_log);
                nexFile_4.WriteLine("={0}= *TESTER*", Tester);
                nexFile_4.WriteLine("={0}= *LOCALENAME*", localename);
                nexFile_4.WriteLine("={0}= *BIOS*", _BIOSversion);
                nexFile_4.WriteLine("={0}= *OS*", OS_Pro_Home);

                    //===========SKU number in actual.log==================
                    if (radioButton_SKU_Harry.Checked == true)
                    {
                        nexFile_4.WriteLine("={0}= *Harry SKU*", textBox_SKU_Harry.Text);
                    }
                    else if (radioButton_SKU_Potter.Checked == true)
                    {
                        nexFile_4.WriteLine("={0}= *Potter SKU*", textBox_SKU_Potter.Text);
                    }
                    //===========SKU number in actual.log==================
                

                    nexFile_4.Close();
                //======== 寫值 Test name + Localization + BIOS version


                //===============↓ Get acutral version for HotFix ==========
                bool hoxfix_found_actual = false;
                string get_version_HotFix(string source_line) //KB1234567
                {
                    string charRange = "_for_KB";
                    int startIndex = source_line.IndexOf(charRange);
                    return source_line.Substring(startIndex + 5, 9);
                }

                string PathString_Hotfix = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Component Based Servicing\\PackageDetect";
                Microsoft.Win32.RegistryKey start_hotfix_actual = Microsoft.Win32.Registry.LocalMachine;
                Microsoft.Win32.RegistryKey programName_hotfix = start_hotfix_actual.OpenSubKey(PathString_Hotfix);
                foreach (string subKeyName in programName_hotfix.GetSubKeyNames())
                {
                    using (Microsoft.Win32.RegistryKey tempKey = programName_hotfix.OpenSubKey(subKeyName))
                    {
                        foreach (string valueName in tempKey.GetValueNames())
                        {
                            if (valueName.Contains("_for_KB"))
                            {
                                string verison_Hotfix = get_version_HotFix(valueName);
                                //MessageBox.Show(verison_Hotfix);
                                StreamWriter nexFile = File.AppendText(path_actual_log);
                                nexFile.WriteLine("={0}= *HOTFIX*", verison_Hotfix);
                                nexFile.Close();
                                hoxfix_found_actual = true;
                                break; //true 找到 跳出迴圈
                            }
                        }
                    }
                    if (hoxfix_found_actual)
                    {
                        break; //true 找到 跳出迴圈
                    }
                }
                //===============↑ Get acutral version for HotFix ==========


                //==============↓====Actual Part 1=======================================
                string keyPathString = "SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall";
                Microsoft.Win32.RegistryKey start = Microsoft.Win32.Registry.LocalMachine;
                Microsoft.Win32.RegistryKey programName = start.OpenSubKey(keyPathString);

                foreach (string subKeyName in programName.GetSubKeyNames())
                {
                    using (Microsoft.Win32.RegistryKey tempKey = programName.OpenSubKey(subKeyName))
                    {

                        foreach (string valueName in tempKey.GetValueNames())
                        {

                            if (
                                 (tempKey.GetValue(valueName).ToString() == "Nexstgo Backup and Recovery") ||
                                 (tempKey.GetValue(valueName).ToString() == "Nexstgo Hotkey Utilities") ||
                                 (tempKey.GetValue(valueName).ToString() == "Nexstgo Power Manager") ||
                                 (tempKey.GetValue(valueName).ToString() == "Nexstgo Software Updater") ||
                                 (tempKey.GetValue(valueName).ToString() == "Realtek High Definition Audio Driver") ||
                                 (tempKey.GetValue(valueName).ToString() == "Realtek PC Camera") ||
                                 (tempKey.GetValue(valueName).ToString() == "Realtek Card Reader") ||
                                 // (tempKey.GetValue(valueName).ToString() == "Intel(R) Chipset Device Software") ||
                                 (tempKey.GetValue(valueName).ToString() == "Intel(R) Processor Graphics")
                               )
                            //if ((tempKey.GetValue(valueName).ToString() == "Nexstgo Backup and Recovery"))
                            {
                                //string pathString1;
                                Microsoft.Win32.RegistryKey start1 = Microsoft.Win32.Registry.LocalMachine;
                                Microsoft.Win32.RegistryKey programName1 = start1.OpenSubKey(tempKey.ToString().Remove(0, 19));

                                if (programName1 != null)
                                {
                                    StreamWriter nexFile = File.AppendText(path_actual_log);
                                    nexFile.WriteLine("={0}= *{1}*", (string)programName1.GetValue("DisplayVersion"), (string)programName1.GetValue("DisplayName"));
                                    nexFile.Close();

                                    //  pathString1 = (string)programName1.GetValue("DisplayVersion");
                                    // Console.WriteLine("{0}", pathString1);
                                }
                            }
                        }
                    }
                }
                //==============↑====Actual Part 1=======================================

                //==============↓====Actual Part 2=======================================
                string path_1 = "SYSTEM\\ControlSet001\\Control\\Class";
                string path_2 = "";
                string path_3 = "";
                Microsoft.Win32.RegistryKey start2 = Microsoft.Win32.Registry.LocalMachine;
                Microsoft.Win32.RegistryKey programName_1 = start2.OpenSubKey(path_1);

                foreach (string subKeyName_1 in programName_1.GetSubKeyNames())
                {
                    path_2 = "SYSTEM\\ControlSet001\\Control\\Class" + "\\" + subKeyName_1;
                    Microsoft.Win32.RegistryKey programName_2 = start2.OpenSubKey(path_2); // SYSTEM\ControlSet001\Control\Class\{e2f84ce7-8efa-411c-aa69-97454ca4cb57} 

                    foreach (string subKeyName_2 in programName_2.GetSubKeyNames())
                    {
                        if (subKeyName_2 != "Properties")
                        {
                            path_3 = path_2 + "\\" + subKeyName_2;
                            Microsoft.Win32.RegistryKey programName_3 = start2.OpenSubKey(path_3); // SYSTEM\ControlSet001\Control\Class\{eec5ad98-8080-425f-922a-dabf3de3f69a}\0000

                            foreach (string valueName in programName_3.GetValueNames()) //讀值
                            {                                    
                                //Lan vPro : PCI\VEN_8086&DEV_156F    vPro才支援SGX
                                //Lan non-vPro : PCI\VEN_8086 & DEV_1570

                                if (
                                       (programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_8086&DEV_5904") //Chipset I3
                                    || (programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_8086&DEV_5914") //Chipset I7
                                    || (programName_3.GetValue(valueName).ToString().ToLower() == "usb\\vid_13d3&pid_3531") //Bluetooth AZ
                                    || (programName_3.GetValue(valueName).ToString().ToLower() == "usb\\vid_0bda&pid_b822") //Bluetooth GSD 
                                    || (programName_3.GetValue(valueName).ToString().ToLower() == "usb\\vid_8087&pid_0a2b&rev_0010")//Bluetooth Intel                
                                    || (programName_3.GetValue(valueName).ToString().ToUpper() == "USB\\VID_27C6&PID_5740&MI_00")//fingerprint
                                    || (programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_8086&DEV_9D03&CC_0106")//IRST
                                    || (programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_8086&DEV_156F")//Intel(R) Ethernet I219-LM
                                    || (programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_8086&DEV_1570")//Intel(R) Ethernet Connection I219-V
                                    || (programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_8086&DEV_156F&SUBSYS_00008086")//Intel(R) Ethernet I219-LM
                                    || (programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_8086&DEV_1570&SUBSYS_00008086")//Intel(R) Ethernet I219-V
                                    || (programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_8086&DEV_9D3A")// ME
                                    || (programName_3.GetValue(valueName).ToString().ToLower() == "acpi\\smo8840")// STMicroelectronics
                                    || (programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_8086&DEV_9D60")//Intel(R) Serial IO
                                    || (programName_3.GetValue(valueName).ToString().ToUpper() == "ACPI\\RTK5445")// UCM
                                    || (programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_10EC&DEV_B822&SUBSYS_29511A3B")//AZ Wireless
                                    || (programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_8086&DEV_24FD&SUBSYS_00108086")//Intel Wireless
                                    || (programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_10EC&DEV_B822&SUBSYS_B82210EC")//GSD Wireless (Realtek 8822BE Wireless LAN 802.11ac PCI-E NIC)
                                    || (programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_10EC&DEV_B822&SUBSYS_54672A3B")//GSD Wireless (Realtek 8822BE Wireless LAN 802.11ac PCI-E NIC)
                                    || (programName_3.GetValue(valueName).ToString().ToUpper() == "ACPI\\INT0E0C") // SGX
                                    || (programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_8086&DEV_282A&CC_0104") // Optance Memory
                                    )
                                {
                                    //Console.WriteLine("{0}", path_3);
                                    //string path_current_2 = System.Environment.CurrentDirectory;
                                    //string path_driver_log = path_current_2 + "\\Driver.log";
                                    StreamWriter nexFile = File.AppendText(path_actual_log);
                                    //nexFile.WriteLine("{0}: {1}", valueName, programName_3.GetValue(valueName).ToString());
                                    nexFile.WriteLine("={0}= *{1}*", (string)programName_3.GetValue("DriverVersion"), (string)programName_3.GetValue("MatchingDeviceId"));
                                    nexFile.Close();
                                    /*
                                    if ((programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_10EC&DEV_B822&SUBSYS_29511A3B"))//AZ Wireless)
                                    {
                                        AZ_Wireless_check = true;
                                    }
                                    if ((programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_10EC&DEV_B822&SUBSYS_B82210EC"))//GSD Wireless)
                                    {
                                        GSD_Wireless_check = true;
                                    }
                                    if ((programName_3.GetValue(valueName).ToString().ToLower() == "usb\\vid_13d3&pid_3531")) //Bluetooth AZ
                                    {
                                        AZ_Bluetooh_check = true;
                                    }
                                    if ((programName_3.GetValue(valueName).ToString().ToLower() == "usb\\vid_0bda&pid_b822"))//Bluetooth GSD 
                                    {
                                        GSD_Bluetooh_check = true;
                                        MessageBox.Show("regular actual");
                                    }
                                    */
                                    //Console.WriteLine("{0,-8}: {1}", valueName,
                                    //    programName_3.GetValue(valueName).ToString());
                                }
                            }
                        }
                    }


                }
                //==============↑====Actual Part 2=======================================

                //==============↓====Actual Part 3=====For Metro ==================================
                string keyPathString_metro = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Appx\\AppxAllUserStore\\Applications";
                //Microsoft.Win32.RegistryKey start = Microsoft.Win32.Registry.LocalMachine;
                Microsoft.Win32.RegistryKey programName_metro = start.OpenSubKey(keyPathString_metro);
                foreach (string subKeyName in programName_metro.GetSubKeyNames())
                {
                    /*
                    if (subKeyName.Contains("2451842CBD778") || subKeyName.ToLower().Contains("foxitmobile") || subKeyName.ToLower().Contains("linked") || subKeyName.ToLower().Contains("nexstgobackup") || subKeyName.ToLower().Contains("nexstgopower") || subKeyName.ToLower().Contains("nexstgoswappgroup"))
                    {
                        String str = subKeyName;
                        String toFind = "_neutral";
                        string version = get_version_Metro(str, toFind);
                        Console.WriteLine("{0},{1}", subKeyName);
                    }
                    */
                    if (subKeyName.ToLower().Contains("linked"))
                    {
                        String str = subKeyName;
                        String toFind = "_neutral";
                        StreamWriter nexFile = File.AppendText(path_actual_log);
                        nexFile.WriteLine("={0}= *LinkedIn*", get_version_Metro(str, toFind));
                        nexFile.Close();
                    }
                    if (subKeyName.ToLower().Contains("foxitmobile"))
                    {
                        String str = subKeyName;
                        String toFind = "_neutral";
                        StreamWriter nexFile = File.AppendText(path_actual_log);
                        nexFile.WriteLine("={0}= *FoxitMobilePDF*", get_version_Metro(str, toFind));
                        nexFile.Close();
                    }
                    if (subKeyName.Contains("2451842CBD778"))
                    {
                        String str = subKeyName;
                        String toFind = "_neutral";
                        StreamWriter nexFile = File.AppendText(path_actual_log);
                        nexFile.WriteLine("={0}= *Nexstgo Software Updater User Guide*", get_version_Metro(str, toFind));
                        nexFile.Close();
                    }
                    if (subKeyName.ToLower().Contains("nexstgobackup"))
                    {
                        String str = subKeyName;
                        String toFind = "_neutral";
                        StreamWriter nexFile = File.AppendText(path_actual_log);
                        nexFile.WriteLine("={0}= *Nexstgo Backup And Recovery User Guide*", get_version_Metro(str, toFind));
                        nexFile.Close();
                    }
                    if (subKeyName.ToLower().Contains("nexstgopower"))
                    {
                        String str = subKeyName;
                        String toFind = "_neutral";
                        StreamWriter nexFile = File.AppendText(path_actual_log);
                        nexFile.WriteLine("={0}= *Nexstgo Power Manager User Guide*", get_version_Metro(str, toFind));
                        nexFile.Close();
                    }
                    if (subKeyName.ToLower().Contains("nexstgoswappgroup"))
                    {
                        String str = subKeyName;
                        String toFind = "_neutral";
                        StreamWriter nexFile = File.AppendText(path_actual_log);
                        nexFile.WriteLine("={0}= *Nexstgo Software Application Group User Guide*", get_version_Metro(str, toFind));
                        nexFile.Close();
                    }
                }
                //==============↑====Actual Part 3=====For Metro ==================================
                progressBar1.Value = 100;
                label_Msg_Actual_Log.Text = "Actual log is done.";
                MessageBox.Show("All Process Completed.");
                label_Msg_Actual_Log.Text = "";
                progressBar1.Visible = false;
                button_Start_Test_Actual_log.Visible = true;
                progressBar1.Value = 30; //還原
                Application.Exit();
            }
            else if (radioButton_Actual_PP.Checked == Enabled) // For Peter / Pan
            {

                label_Msg_Actual_Log.Text = "Actual log is being created ...";
                string path_current = System.Environment.CurrentDirectory;
                string path_actual_log = path_current + "\\Peter_Pan_Actual_" + Number_Actual_log + ".log";

                while (File.Exists(path_actual_log)) // Actual.log already exist ?
                {
                    Number_Actual_log++;
                    path_actual_log = path_current + "\\Peter_Pan_Actual_" + Number_Actual_log + ".log";
                }

                //===============Jumpstart check ↓===============
                //  Jumpstart Check  
                bool found_jumpstart = false;
                string line_jumpstart = "";
                string result_in_jumpstart = "C:\\temp\\results_summary.txt";
                try
                {
                    // System.IO.StreamReader jumpstart_Content = new System.IO.StreamReader(result_in_jumpstart);
                    using (FileStream file = new FileStream(result_in_jumpstart, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite))
                    {
                        using (StreamReader jumpstart_Content = new StreamReader (file))
                        {
                            //Do your codes here 
                            while ((line_jumpstart = jumpstart_Content.ReadLine()) != null)
                            {

                                if (line_jumpstart.Contains("Jumpstart Compliance:")) // Software Title
                                {
                                    Console.WriteLine("{0}", line_jumpstart);
                                    found_jumpstart = true;
                                    if (line_jumpstart.Contains("PASSED"))
                                    {
                                        StreamWriter nexFile = File.AppendText(path_actual_log);
                                        nexFile.WriteLine("=PASSED= *Jumpstart*");
                                        nexFile.Close();
                                    }
                                    else if (line_jumpstart.Contains("FAILED"))
                                    {
                                        StreamWriter nexFile = File.AppendText(path_actual_log);
                                        nexFile.WriteLine("=FAILED= *Jumpstart*");
                                        nexFile.Close();
                                    }
                                    else
                                    {
                                        // NO Result found
                                        StreamWriter nexFile = File.AppendText(path_actual_log);
                                        nexFile.WriteLine("=NO RESULT= *Jumpstart*");
                                        nexFile.Close();
                                    }

                                }

                                if (found_jumpstart)
                                {
                                    jumpstart_Content.Close();
                                    break;
                                }
                            }
                        }
                    }

                  
                }
                catch
                {
                    MessageBox.Show("results_summary.txt Not Found", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    //NO Result found
                    StreamWriter nexFile = File.AppendText(path_actual_log);
                    nexFile.WriteLine("=results_summary.txt Not Found= *Jumpstart*"); 
                    nexFile.Close();
                    
                }
                //===============Jumpstart check ↑===============

                //===========判斷 Home or Pro======================
                string OS_Pro_Home = "";
                string os_PathString = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion";
                Microsoft.Win32.RegistryKey start_home_pro = Microsoft.Win32.Registry.LocalMachine;
                Microsoft.Win32.RegistryKey programName_home_pro = start_home_pro.OpenSubKey(os_PathString);
                string OS_version = (string)programName_home_pro.GetValue("ProductName");
                //Console.WriteLine("{0}", OS_version);
                if (OS_version.Contains("Windows 10 Pro"))
                {
                    OS_Pro_Home = "Pro 64";
                }
                else if (OS_version.Contains("Windows 10 Home"))
                {
                    OS_Pro_Home = "Home 64";
                }
                else
                {
                    MessageBox.Show("Not supported OS", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                //===========判斷 Home or Pro======================


                //============== ↓ Get version for Image ===========
                string short_path = @"C:\NexstGo.sav";
                string[] files = System.IO.Directory.GetFiles(short_path, "*.*", System.IO.SearchOption.TopDirectoryOnly);
                foreach (string full_path in files)
                {
                    string path_current_jumpstart = System.Environment.CurrentDirectory;
                    if (full_path.Contains("333N"))
                    {
                        string version = full_path.Remove(0, 15);
                        StreamWriter nexFile = File.AppendText(path_actual_log);
                        nexFile.WriteLine("={0}= *IMAGE*", version);
                        nexFile.Close();
                        if (version.Contains("333N001"))
                        {
                            StreamWriter nexFile_3 = File.AppendText(path_actual_log);
                            nexFile_3.WriteLine("=Harry= *PROJECT*");
                            nexFile_3.Close();
                        }
                        else if (version.Contains("333N002"))
                        {
                            StreamWriter nexFile_3 = File.AppendText(path_actual_log);
                            nexFile_3.WriteLine("=Potter= *PROJECT*");
                            nexFile_3.Close();
                        }
                        else if (version.Contains("333N003"))
                        {
                            StreamWriter nexFile_3 = File.AppendText(path_actual_log);
                            nexFile_3.WriteLine("=Peter= *PROJECT*");
                            nexFile_3.Close();
                        }
                        else if (version.Contains("333N004"))
                        {
                            StreamWriter nexFile_3 = File.AppendText(path_actual_log);
                            nexFile_3.WriteLine("=Pan= *PROJECT*");
                            nexFile_3.Close();
                        }
                    }
                }
                //============== ↑ Get version for Image ===========


                //=============== Tester name ===========
                string tester_path = "Volatile Environment";
                Microsoft.Win32.RegistryKey start_tester = Microsoft.Win32.Registry.CurrentUser;
                Microsoft.Win32.RegistryKey programName_tester = start_tester.OpenSubKey(tester_path);
                string Tester = (string)programName_tester.GetValue("USERNAME");
                //=============== Tester name =========== 

                //=============== Localization ===========
                string path_Locale_Name = ".DEFAULT\\Control Panel\\International";
                Microsoft.Win32.RegistryKey start_LocaleName = Microsoft.Win32.Registry.Users;
                Microsoft.Win32.RegistryKey programName_localename = start_LocaleName.OpenSubKey(path_Locale_Name);
                string localename = (string)programName_localename.GetValue("LocaleName");
                //=============== Localization ===========

                //---------------------------BIOS Version-----------------------------//
                string _BIOSversion = "";
                using (ManagementObjectSearcher mos = new ManagementObjectSearcher("SELECT * FROM Win32_BIOS"))
                using (ManagementObjectCollection mob = mos.Get())
                {
                    StringBuilder sb = new StringBuilder();

                    foreach (ManagementObject mo in mob)
                    {
                        string[] BIOSVersions = (string[])mo["BIOSVersion"];
                        _BIOSversion = BIOSVersions[1];
                    }
                    //MessageBox.Show(_BIOSversion.ToString());
                }
                //---------------------------BIOS Version-----------------------------//

                //======== 寫值 Test name + Localization
                StreamWriter nexFile_4 = File.AppendText(path_actual_log);
                nexFile_4.WriteLine("={0}= *TESTER*", Tester);
                nexFile_4.WriteLine("={0}= *LOCALENAME*", localename);
                nexFile_4.WriteLine("={0}= *BIOS*", _BIOSversion);
                nexFile_4.WriteLine("={0}= *OS*", OS_Pro_Home);

                //===========SKU number in actual.log==================
                if (radioButton_SKU_Peter.Checked == true)
                {
                    nexFile_4.WriteLine("={0}= *Peter SKU*", textBox_SKU_Peter.Text);
                }
                else if (radioButton_SKU_Pan.Checked == true)
                {
                    nexFile_4.WriteLine("={0}= *Pan SKU*", textBox_SKU_Pan.Text);
                }
                //===========SKU number in actual.log==================
                nexFile_4.Close();
                //======== 寫值 Test name + Localization


                //===============↓ Get acutral version for HotFix ==========
                bool hoxfix_found_actual = false;
                string get_version_HotFix(string source_line) //KB1234567
                {
                    string charRange = "_for_KB";
                    int startIndex = source_line.IndexOf(charRange);
                    return source_line.Substring(startIndex + 5, 9);
                }

                string PathString_Hotfix = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Component Based Servicing\\PackageDetect";
                Microsoft.Win32.RegistryKey start_hotfix_actual = Microsoft.Win32.Registry.LocalMachine;
                Microsoft.Win32.RegistryKey programName_hotfix = start_hotfix_actual.OpenSubKey(PathString_Hotfix);
                foreach (string subKeyName in programName_hotfix.GetSubKeyNames())
                {
                    using (Microsoft.Win32.RegistryKey tempKey = programName_hotfix.OpenSubKey(subKeyName))
                    {
                        foreach (string valueName in tempKey.GetValueNames())
                        {
                            if (valueName.Contains("_for_KB"))
                            {
                                string verison_Hotfix = get_version_HotFix(valueName);
                                //MessageBox.Show(verison_Hotfix);
                                StreamWriter nexFile = File.AppendText(path_actual_log);
                                nexFile.WriteLine("={0}= *HOTFIX*", verison_Hotfix);
                                nexFile.Close();
                                hoxfix_found_actual = true;
                                break; //true 找到 跳出迴圈
                            }
                        }
                    }
                    if (hoxfix_found_actual)
                    {
                        break; //true 找到 跳出迴圈
                    }
                }
                //===============↑ Get acutral version for HotFix ==========


                //==============↓====Actual Part 1=======================================
                string keyPathString = "SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall";
                Microsoft.Win32.RegistryKey start = Microsoft.Win32.Registry.LocalMachine;
                Microsoft.Win32.RegistryKey programName = start.OpenSubKey(keyPathString);

                foreach (string subKeyName in programName.GetSubKeyNames())
                {
                    using (Microsoft.Win32.RegistryKey tempKey = programName.OpenSubKey(subKeyName))
                    {

                        foreach (string valueName in tempKey.GetValueNames())
                        {

                            if (
                                (tempKey.GetValue(valueName).ToString().Contains("Control Center")) ||
                                 (tempKey.GetValue(valueName).ToString() == "Nexstgo Backup and Recovery") ||
                                 (tempKey.GetValue(valueName).ToString() == "Nexstgo Software Updater") ||
                                 (tempKey.GetValue(valueName).ToString() == "Realtek High Definition Audio Driver") ||
                                 (tempKey.GetValue(valueName).ToString() == "Realtek Card Reader") ||
                                 // (tempKey.GetValue(valueName).ToString() == "Intel(R) Chipset Device Software") ||
                                 (tempKey.GetValue(valueName).ToString() == "Intel(R) Processor Graphics")
                               )
                            //if ((tempKey.GetValue(valueName).ToString() == "Nexstgo Backup and Recovery"))
                            {
                                //string pathString1;
                                Microsoft.Win32.RegistryKey start1 = Microsoft.Win32.Registry.LocalMachine;
                                Microsoft.Win32.RegistryKey programName1 = start1.OpenSubKey(tempKey.ToString().Remove(0, 19));

                                if (programName1 != null)
                                {
                                    StreamWriter nexFile = File.AppendText(path_actual_log);
                                    nexFile.WriteLine("={0}= *{1}*", (string)programName1.GetValue("DisplayVersion"), (string)programName1.GetValue("DisplayName"));
                                    nexFile.Close();

                                    //  pathString1 = (string)programName1.GetValue("DisplayVersion");
                                    // Console.WriteLine("{0}", pathString1);
                                }
                            }
                        }
                    }
                }
                //Console.WriteLine("Actual.log Done!");
                //==============↑====Actual Part 1=======================================

                //==============↓====Actual Part 2=======================================
                string path_1 = "SYSTEM\\ControlSet001\\Control\\Class";
                string path_2 = "";
                string path_3 = "";
                Microsoft.Win32.RegistryKey start2 = Microsoft.Win32.Registry.LocalMachine;
                Microsoft.Win32.RegistryKey programName_1 = start2.OpenSubKey(path_1);

                foreach (string subKeyName_1 in programName_1.GetSubKeyNames())
                {
                    path_2 = "SYSTEM\\ControlSet001\\Control\\Class" + "\\" + subKeyName_1;
                    Microsoft.Win32.RegistryKey programName_2 = start2.OpenSubKey(path_2); // SYSTEM\ControlSet001\Control\Class\{e2f84ce7-8efa-411c-aa69-97454ca4cb57} 

                    foreach (string subKeyName_2 in programName_2.GetSubKeyNames())
                    {
                        if (subKeyName_2 != "Properties")
                        {
                            path_3 = path_2 + "\\" + subKeyName_2;
                            Microsoft.Win32.RegistryKey programName_3 = start2.OpenSubKey(path_3); // SYSTEM\ControlSet001\Control\Class\{eec5ad98-8080-425f-922a-dabf3de3f69a}\0000

                            foreach (string valueName in programName_3.GetValueNames()) //讀值
                            {

                                if (
                                       (programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_8086&DEV_5904") //Chipset I3
                                    || (programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_8086&DEV_5914") //Chipset I7
                                    || (programName_3.GetValue(valueName).ToString().ToLower() == "acpi\\ven_pnp&dev_c000")//Insyde Airplane Mode HID Mini-Driver
                                    || (programName_3.GetValue(valueName).ToString().ToLower() == "usb\\vid_8087&pid_0aa7")//Intel(R) Wireless Bluetooth(R)
                                    || (programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_8086&DEV_9D03&CC_0106")//Intel(R) 6th Generation Core Processor Family Platform I/O SATA AHCI Controller
                                    || (programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_10EC&DEV_8168&SUBSYS_31071DC2&REV_12")//Realtek PCIe GBE Family Controller
                                    || (programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_10EC&DEV_8168&SUBSYS_31061DC2&REV_12")//Realtek PCIe GBE Family Controller
                                    || (programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_8086&DEV_9D3A")//Intel(R) Management Engine Interface
                                    || (programName_3.GetValue(valueName).ToString().ToLower() == "acpi\\syn1222")//Synaptics SMBus TouchPad
                                    || (programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_8086&DEV_24FB&SUBSYS_21108086")//Intel(R) Dual Band Wireless-AC 3168
                                    )
                                {
                                    //Console.WriteLine("{0}", path_3);
                                    //string path_current_2 = System.Environment.CurrentDirectory;
                                    //string path_driver_log = path_current_2 + "\\Driver.log";
                                    StreamWriter nexFile = File.AppendText(path_actual_log);
                                    //nexFile.WriteLine("{0}: {1}", valueName, programName_3.GetValue(valueName).ToString());
                                    nexFile.WriteLine("={0}= *{1}*", (string)programName_3.GetValue("DriverVersion"), (string)programName_3.GetValue("MatchingDeviceId"));
                                    nexFile.Close();
                                    //Console.WriteLine("{0,-8}: {1}", valueName,
                                    //    programName_3.GetValue(valueName).ToString());
                                }
                            }
                        }
                    }


                }
                //==============↑====Actual Part 2=======================================
                //==============↓====Actual Part 3=====For Metro ==================================
                string keyPathString_metro = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Appx\\AppxAllUserStore\\Applications";
                //Microsoft.Win32.RegistryKey start = Microsoft.Win32.Registry.LocalMachine;
                Microsoft.Win32.RegistryKey programName_metro = start.OpenSubKey(keyPathString_metro);
                foreach (string subKeyName in programName_metro.GetSubKeyNames())
                {
                    /*
                    if (subKeyName.Contains("2451842CBD778") || subKeyName.ToLower().Contains("foxitmobile") || subKeyName.ToLower().Contains("linked") || subKeyName.ToLower().Contains("nexstgobackup") || subKeyName.ToLower().Contains("nexstgopower") || subKeyName.ToLower().Contains("nexstgoswappgroup"))
                    {
                        String str = subKeyName;
                        String toFind = "_neutral";
                        string version = get_version_Metro(str, toFind);
                        Console.WriteLine("{0},{1}", subKeyName);
                    }
                    */
                    if (subKeyName.ToLower().Contains("linked"))
                    {
                        String str = subKeyName;
                        String toFind = "_neutral";
                        StreamWriter nexFile = File.AppendText(path_actual_log);
                        nexFile.WriteLine("={0}= *LinkedIn*", get_version_Metro(str, toFind));
                        nexFile.Close();
                    }
                    if (subKeyName.ToLower().Contains("foxitmobile"))
                    {
                        String str = subKeyName;
                        String toFind = "_neutral";
                        StreamWriter nexFile = File.AppendText(path_actual_log);
                        nexFile.WriteLine("={0}= *FoxitMobilePDF*", get_version_Metro(str, toFind));
                        nexFile.Close();
                    }
                    if (subKeyName.Contains("2451842CBD778"))
                    {
                        String str = subKeyName;
                        String toFind = "_neutral";
                        StreamWriter nexFile = File.AppendText(path_actual_log);
                        nexFile.WriteLine("={0}= *Nexstgo Software Updater User Guide*", get_version_Metro(str, toFind));
                        nexFile.Close();
                    }
                    if (subKeyName.ToLower().Contains("nexstgobackup"))
                    {
                        String str = subKeyName;
                        String toFind = "_neutral";
                        StreamWriter nexFile = File.AppendText(path_actual_log);
                        nexFile.WriteLine("={0}= *Nexstgo Backup And Recovery User Guide*", get_version_Metro(str, toFind));
                        nexFile.Close();
                    }
                    if (subKeyName.ToLower().Contains("nexstgopower"))
                    {
                        String str = subKeyName;
                        String toFind = "_neutral";
                        StreamWriter nexFile = File.AppendText(path_actual_log);
                        nexFile.WriteLine("={0}= *Nexstgo Power Manager User Guide*", get_version_Metro(str, toFind));
                        nexFile.Close();
                    }
                    if (subKeyName.ToLower().Contains("nexstgoswappgroup"))
                    {
                        String str = subKeyName;
                        String toFind = "_neutral";
                        StreamWriter nexFile = File.AppendText(path_actual_log);
                        nexFile.WriteLine("={0}= *Nexstgo Software Application Group User Guide*", get_version_Metro(str, toFind));
                        nexFile.Close();
                    }
                }
                //==============↑====Actual Part 3=====For Metro ==================================
                progressBar1.Value = 100;
                label_Msg_Actual_Log.Text = "Actual log is done.";
                MessageBox.Show("All Process Completed.");
                label_Msg_Actual_Log.Text = "";
                progressBar1.Visible = false;
                button_Start_Test_Actual_log.Visible = true;
                progressBar1.Value = 30; //還原
                Application.Exit();

            }
            //=================Get Actual Log ↑↑↑==================


        }








        private void button_Save_Rows_Click(object sender, EventArgs e)
        {

            Properties.Settings set = Properties.Settings.Default;
            DialogResult dc;
            dc = MessageBox.Show("Are you sure to save ?", "Reminder", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dc == DialogResult.Yes)
            {
                //jumpstart
                set.Jumpstart = textBox_Jumpstart.Text;
                //Harry Potter
                set.HP_Driver_Start = textBox_HP_D1.Text;
                set.HP_Driver_End = textBox_HP_D2.Text;
                set.HP_APP_Start = textBox_HP_A1.Text;
                set.HP_APP_End = textBox_HP_A2.Text;
                set.HP_Hotfix = textBox_HP_Hotfix.Text;
                //Peter Pan
                set.PP_Driver_Start = textBox_PP_D1.Text;
                set.PP_Driver_End = textBox_PP_D2.Text;
                set.PP_APP_Start = textBox_PP_A1.Text;
                set.PP_APP_End = textBox_PP_A2.Text;
                set.PP_Hotfix = textBox_PP_Hotfix.Text;
                //存檔
                set.Save();
                Modified_Record_Request_Form = false;
                MessageBox.Show("Save Successfully");
            }
            else if (dc == DialogResult.No)
            {
                //Jumpstart
                textBox_Jumpstart.Text = set.Jumpstart;

                //Harry Potter
                textBox_HP_D1.Text = set.HP_Driver_Start;
                textBox_HP_D2.Text = set.HP_Driver_End;
                textBox_HP_A1.Text = set.HP_APP_Start;
                textBox_HP_A2.Text = set.HP_APP_End;
                textBox_HP_Hotfix.Text = set.HP_Hotfix;

                //Peter Pan
                textBox_PP_D1.Text = set.PP_Driver_Start;
                textBox_PP_D2.Text = set.PP_Driver_End;
                textBox_PP_A1.Text = set.PP_APP_Start;
                textBox_PP_A2.Text = set.PP_APP_End;
                textBox_PP_Hotfix.Text = set.PP_Hotfix;

                //return;
                Modified_Record_Request_Form = false;
            }

        }

        private void button_Start_Test_Result_Compare_Click(object sender, EventArgs e)
        {



            button_Start_Test_Result_Compare.Visible = false;
            if (radioButton_ResultCompare_HP.Checked == true) // Harry Potter
            {

                string line = "";
                string OS_Pro_Home_from_actual_log = "";
                string path_current_1 = System.Environment.CurrentDirectory;
                string path_request_form = path_current_1 + "\\Harry_Potter_Request_Form.xlsx";
                string path_Report = path_current_1 + "\\Harry_Potter_Report.xlsx";
                string path_actual_log = path_current_1 + "\\Harry_Potter_Actual_" + Number_Actual_log + ".log";
                //MessageBox.Show(path_actual_log);
                string path_expected_log = path_current_1 + "\\Harry_Potter_expected.log";

                bool AZ_Bluetooh_check = false;
                bool GSD_Bluetooh_check = false;
                bool AZ_Wireless_check = false;
                bool GSD_Wireless_check = false;
                bool file_ready = false;
                bool vPro_Lan = false; //PCI\VEN_8086&DEV_156F
                bool OM_exist = false;
                bool IRST_exist = false;

                string search_in_log(string source_line, char find_value)  //處理 "=" 拿掉
                {
                    char charRange = find_value;
                    int startIndex = source_line.IndexOf(charRange);
                    int endIndex = source_line.LastIndexOf(charRange);
                    int length = endIndex - startIndex - 1;
                    return source_line.Substring(startIndex + 1, length);
                }


                Properties.Settings set = Properties.Settings.Default;
                Jumpstart_file_name = set.Jumpstart;
                HP_Driver_start = int.Parse(set.HP_Driver_Start);
                HP_Drivr_end = int.Parse(set.HP_Driver_End);
                HP_app_start = int.Parse(set.HP_APP_Start);
                HP_app_end = int.Parse(set.HP_APP_End);
                HP_hotfix = int.Parse(set.HP_Hotfix);
                

                DialogResult dc;

                if (File_All_Ready == false)
                {
                    dc = MessageBox.Show("Harry_Potter_Request_Form.xlsx \nHarry_Potter_Report.xlsx \nHarry_Potter_Actual.log\n\nAll are ready?", "Reminder", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                    if (dc == DialogResult.Yes)
                    {
                        File_All_Ready = true;
                    }
                    else if (dc == DialogResult.No)
                    {
                        button_Start_Test_Result_Compare.Visible = true;
                        return;
                    }
                }
               
                if (File_All_Ready == true)
                {
                    if (!(File.Exists(path_request_form)))
                    {
                        MessageBox.Show("Harry_Potter_Request_Form.xlsx Not Found", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        button_Start_Test_Result_Compare.Visible = true;
                        return;
                    }
                    if (!(File.Exists(path_Report)))
                    {
                        MessageBox.Show("Harry_Potter_Report.xlsx Not Found", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        button_Start_Test_Result_Compare.Visible = true;
                        return;
                    }
                    if (!(File.Exists(path_actual_log)))
                    {
                        MessageBox.Show("Harry_Potter_Actual.log Not Found", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        button_Start_Test_Result_Compare.Visible = true;
                        return;
                    }
                    progressBar2.Visible = true;
                    label_Msg_2.Text = "Actual.log_" + Number_Actual_log + " Is In Progress";


                    if (File.Exists(path_expected_log)) // Expected.log already exist ?
                    {
                        File.Delete(path_expected_log);
                    }


                    //應用程序
                    Excel.Application Excel_APP1 = new Excel.Application();
                    Excel.Application Excel_APP_Expected = new Excel.Application();
                    //檔案
                    Excel.Workbook Excel_WB1 = Excel_APP1.Workbooks.Open(path_Report);
                    Excel.Workbook Excel_WB_Expect = Excel_APP_Expected.Workbooks.Open(path_request_form);
                    //工作表
                    // Excel.Worksheet Excel_WS1 = new Excel.Worksheet();

                    //自動改sheet name
                    Excel.Worksheet ws = (Excel.Worksheet)Excel_APP_Expected.Worksheets.get_Item(1);
                    ws.Name = "HARRY_Image_Build_Request_Form_";
                    //自動改sheet name

                    //===========判斷 Home or Pro======================
                    /*
                    string os_PathString = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion";
                    Microsoft.Win32.RegistryKey start_home_pro = Microsoft.Win32.Registry.LocalMachine;
                    Microsoft.Win32.RegistryKey programName_home_pro = start_home_pro.OpenSubKey(os_PathString);
                    string OS_version = (string)programName_home_pro.GetValue("ProductName");
                    //Console.WriteLine("{0}", OS_version);
                    if (OS_version.Contains("Windows 10 Pro"))
                    {
                        OS_Pro_Home = "Pro 64";
                    }
                    else if (OS_version.Contains("Windows 10 Home"))
                    {
                        OS_Pro_Home = "Home 64";
                    }
                    else
                    {
                        MessageBox.Show("Not supported OS", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    */
                    //===========判斷 Home or Pro======================
                    progressBar2.Value = 60;


                    // Get *OS* from actual.log
                    using (FileStream file = new FileStream(path_actual_log, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite))
                    {
                        string line_temp_2 = "";
                        using (StreamReader Actual_log_Content = new StreamReader(file))
                        {
                            //Do your codes here 
                            while ((line_temp_2 = Actual_log_Content.ReadLine()) != null)
                            {
                                if (line_temp_2.Contains("*OS*"))
                                {
                                    char key_1 = '=';
                                    string version_Image = search_in_log(line_temp_2, key_1);
                                    OS_Pro_Home_from_actual_log = version_Image;
                                }
                            }

                        }
                    }
                    if (OS_Pro_Home_from_actual_log == "Pro 64")
                    {
                        Columns_Report_Pro += 3;
                        Columns_Report = Columns_Report_Pro;
                    }
                    else if (OS_Pro_Home_from_actual_log == "Home 64")
                    {
                        Columns_Report_Home += 3;
                        Columns_Report = Columns_Report_Home;
                    }
                    Excel.Worksheet Excel_WS1 = (Excel.Worksheet)Excel_WB1.Sheets[OS_Pro_Home_from_actual_log]; // Result.xlsx
                    Excel.Worksheet Excel_WS_Expect = (Excel.Worksheet)Excel_WB_Expect.Sheets["HARRY_Image_Build_Request_Form_"];                   
                    Excel.Worksheet Excel_WS_Harry_PVT = (Excel.Worksheet)Excel_WB1.Sheets[textBox_Spec_SheetName_Harry.Text]; 
                    Excel.Worksheet Excel_WS_Potter_PVT = (Excel.Worksheet)Excel_WB1.Sheets[textBox_Spec_SheetName_Potter.Text];
                    // 測試中....讀取
                    Microsoft.Office.Interop.Excel.Range range_result;
                    Microsoft.Office.Interop.Excel.Range range_expected_name;
                    Microsoft.Office.Interop.Excel.Range range_expected_version;
                    Microsoft.Office.Interop.Excel.Range sku_name;
                    //========================= For Image partnumber ================
                    
                    using (FileStream file = new FileStream(path_actual_log, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite))
                    {
                        string line_temp_2 = "";
                        using (StreamReader Actual_log_Content = new StreamReader(file))
                        {
                            //Do your codes here 
                            while ((line_temp_2 = Actual_log_Content.ReadLine()) != null)
                            {
                                if (line_temp_2.Contains("*IMAGE*"))
                                {
                                    char key_1 = '=';
                                    string version_Image = search_in_log(line_temp_2, key_1);
                                    Excel_WS1.Cells[2, Columns_Report] = version_Image;
                                }
                            }

                        }
                    }

                    //========================= For Image partnumber ================


                    //==========↓ 處理SKU number in Actual.log===============
                    string Which_SKU = "";
                    string SKU_Number_Actual_Log = "";
                    //string Actual_log = path_actual_log;
                    System.IO.StreamReader Actual_log_content_sku_number = new System.IO.StreamReader(path_actual_log);
                    while ((line = Actual_log_content_sku_number.ReadLine()) != null)
                    {
                        if (line.Contains("*Harry SKU*") )//讀 Actual.log
                        {
                            Which_SKU = "Harry";
                            char key_1 = '=';
                            SKU_Number_Actual_Log = search_in_log(line, key_1);
                            Actual_log_content_sku_number.Close();
                            break; //找到, 不用再找了
                        }
                        else if (line.Contains("*Potter SKU*"))//讀 Actual.log
                        {
                            Which_SKU = "Potter";
                            char key_1 = '=';
                            SKU_Number_Actual_Log = search_in_log(line, key_1);
                            Actual_log_content_sku_number.Close();
                            break; //找到, 不用再找了
                        }
                    }
                    Actual_log_content_sku_number.Close();
                    //==========↑ 處理SKU number in Actual.log===============


                    //==================SKU=======HarryPotter==================
                    int sku_number;
                    ArrayList SKU_arrylist = new ArrayList();
                    int column = 0;
                    
                    if (Which_SKU == "Harry")
                    {
                        try
                        {
                            sku_number = int.Parse(SKU_Number_Actual_Log.Remove(1, SKU_Number_Actual_Log.Length - 1));
                            SKU_arrylist.Add("Harry / SKU" + SKU_Number_Actual_Log);
                            switch (sku_number)
                            {
                                case 1:  // SKU 幾
                                    column = 2;
                                    break;
                                case 2:
                                    column = 3;
                                    break;
                                case 3:
                                    column = 4;
                                    break;
                                case 4:
                                    column = 5;
                                    break;
                                default:
                                    MessageBox.Show("SKU number is out of range on Harry unit.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    //存檔
                                    Excel_WB1.Save();
                                    Excel_WB_Expect.Save();
                                    //關閉及釋放物件
                                    ws = null;
                                    Excel_WS1 = null;
                                    Excel_WS_Expect = null;
                                    Excel_WB1.Close();
                                    Excel_WB_Expect.Close();
                                    Excel_WB1 = null;
                                    Excel_WB_Expect = null;
                                    Excel_APP1.Quit();
                                    Excel_APP_Expected.Quit();
                                    Excel_APP1 = null;
                                    Excel_APP_Expected = null;
                                    Application.Exit();
                                    break;
                            }
                            for (int x = column; x <= column; x++)
                                for (int y = int.Parse(textBox_Spec_rows_Harry_Start.Text); y <= int.Parse(textBox_Spec_rows_Harry_End.Text); y++)
                                {
                                    sku_name = (Microsoft.Office.Interop.Excel.Range)Excel_WS_Harry_PVT.Cells[y, x];
                                    SKU_arrylist.Add(sku_name.Text.ToString());
                                    // MessageBox.Show(sku_name.Text.ToString());
                                }

                        }
                        catch
                        {
                            MessageBox.Show("Invalid SKU number on Harry.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            //存檔
                            Excel_WB1.Save();
                            Excel_WB_Expect.Save();
                            //關閉及釋放物件
                            ws = null;
                            Excel_WS1 = null;
                            Excel_WS_Expect = null;
                            Excel_WB1.Close();
                            Excel_WB_Expect.Close();
                            Excel_WB1 = null;
                            Excel_WB_Expect = null;
                            Excel_APP1.Quit();
                            Excel_APP_Expected.Quit();
                            Excel_APP1 = null;
                            Excel_APP_Expected = null;
                            Application.Exit();                           
                        }
                    }
                    else if (Which_SKU == "Potter")
                    {
                        try
                        {
                            sku_number = int.Parse(SKU_Number_Actual_Log.Remove(1, SKU_Number_Actual_Log.Length - 1));
                            SKU_arrylist.Add("Potter / SKU" + SKU_Number_Actual_Log);
                            switch (sku_number)
                            {
                                case 1:  // SKU 幾
                                    column = 2;
                                    break;
                                case 2:
                                    column = 3;
                                    break;
                                case 3:
                                    column = 4;
                                    break;
                                case 4:
                                    column = 5;
                                    break;
                                default:
                                    MessageBox.Show("SKU number is out of range on Potter unit.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    //存檔
                                    Excel_WB1.Save();
                                    Excel_WB_Expect.Save();
                                    //關閉及釋放物件
                                    ws = null;
                                    Excel_WS1 = null;
                                    Excel_WS_Expect = null;
                                    Excel_WB1.Close();
                                    Excel_WB_Expect.Close();
                                    Excel_WB1 = null;
                                    Excel_WB_Expect = null;
                                    Excel_APP1.Quit();
                                    Excel_APP_Expected.Quit();
                                    Excel_APP1 = null;
                                    Excel_APP_Expected = null;
                                    Application.Exit();
                                    break;
                            }
                            for (int x = column; x <= column; x++)
                                for (int y = int.Parse(textBox_Spec_rows_Potter_Start.Text); y <= int.Parse(textBox_Spec_rows_Potter_End.Text); y++)
                                {
                                    sku_name = (Microsoft.Office.Interop.Excel.Range)Excel_WS_Potter_PVT.Cells[y, x];
                                    SKU_arrylist.Add(sku_name.Text.ToString());
                                    // MessageBox.Show(sku_name.Text.ToString());
                                }
                        }
                        catch
                        {
                            MessageBox.Show("Invalid SKU number on Potter.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            //存檔
                            Excel_WB1.Save();
                            Excel_WB_Expect.Save();
                            //關閉及釋放物件
                            ws = null;
                            Excel_WS1 = null;
                            Excel_WS_Expect = null;
                            Excel_WB1.Close();
                            Excel_WB_Expect.Close();
                            Excel_WB1 = null;
                            Excel_WB_Expect = null;
                            Excel_APP1.Quit();
                            Excel_APP_Expected.Quit();
                            Excel_APP1 = null;
                            Excel_APP_Expected = null;
                            Application.Exit();
                        }
                    }
                    
                    //==================SKU======HarryPotter===================

                    //===============↓==Expected=====================================
                    int check_for_Graphics = 1;
                    int check_for_BT = 1;
                    int check_for_WLAN = 1;
                    for (int x = HP_Driver_start; x <= HP_Drivr_end; x++)  // Requested Form的上半部 2,2 ~ 2,21     6,2 ~ 6,21
                    {
                        for (int y = 2; y <= 2; y++)
                        {
                            for (int z = 6; z <= 6; z++)
                            {
                                range_expected_name = (Microsoft.Office.Interop.Excel.Range)Excel_WS_Expect.Cells[x, y];
                                range_expected_version = (Microsoft.Office.Interop.Excel.Range)Excel_WS_Expect.Cells[x, z];
                                StreamWriter nexFile = File.AppendText(path_expected_log);
                                if (range_expected_name.Text.ToString() == "Bluetooth")
                                {
                                    string temp = range_expected_name.Text.ToString();
                                    temp = temp + check_for_BT.ToString();
                                    nexFile.WriteLine("={0}= *{1}*", range_expected_version.Text.ToString(), temp);
                                    nexFile.Close();
                                    if (check_for_BT == 3)
                                    {
                                        check_for_BT = 1;
                                    }
                                    check_for_BT++;
                                    continue;
                                }

                                if (range_expected_name.Text.ToString() == "Graphics")
                                {
                                    string temp = range_expected_name.Text.ToString();
                                    temp = temp + check_for_Graphics.ToString();
                                    nexFile.WriteLine("={0}= *{1}*", range_expected_version.Text.ToString(), temp);
                                    nexFile.Close();
                                    if (check_for_Graphics == 2)
                                    {
                                        check_for_Graphics = 1;
                                    }
                                    check_for_Graphics++;
                                    continue;
                                }

                                if (range_expected_name.Text.ToString() == "Wireless LAN")
                                {
                                    string temp = range_expected_name.Text.ToString();
                                    temp = temp + check_for_WLAN.ToString();
                                    nexFile.WriteLine("={0}= *{1}*", range_expected_version.Text.ToString(), temp);
                                    nexFile.Close();
                                    if (check_for_WLAN == 3)
                                    {
                                        check_for_WLAN = 1;
                                    }
                                    check_for_WLAN++;
                                    continue;
                                }
                                nexFile.WriteLine("={0}= *{1}*", range_expected_version.Text.ToString(), range_expected_name.Text.ToString());
                                nexFile.Close();

                            }
                        }
                    }

                    for (int x = HP_app_start; x <= HP_app_end; x++)  // Requested Form的下半部  2,22 ~ 2,34  and 4,22 ~ 4,34
                    {
                        for (int y = 2; y <= 2; y++)
                        {
                            for (int z = 4; z <= 4; z++)
                            {
                                range_expected_name = (Microsoft.Office.Interop.Excel.Range)Excel_WS_Expect.Cells[x, y];
                                range_expected_version = (Microsoft.Office.Interop.Excel.Range)Excel_WS_Expect.Cells[x, z];
                                //aa = range_expected_name.Text.ToString();
                                //Console.WriteLine("=Version={0}=Version=  =Name={1}=Name=", range_expected_version.Text.ToString() ,range_expected_name.Text.ToString());
                                StreamWriter nexFile = File.AppendText(path_expected_log);
                                nexFile.WriteLine("={0}= *{1}*", range_expected_version.Text.ToString(), range_expected_name.Text.ToString());
                                nexFile.Close();
                            }
                        }
                    }
                    //==============↑====Expected=======================================
                    //=============↓==Hot Fixed====================================
                    for (int x = HP_hotfix; x <= HP_hotfix; x++)
                    {
                        for (int y = 3; y <= 3; y++)
                        {
                            range_expected_version = (Microsoft.Office.Interop.Excel.Range)Excel_WS_Expect.Cells[x, y];
                            //aa = range_expected_name.Text.ToString();
                            //Console.WriteLine("=Version={0}=Version=  =Name={1}=Name=", range_expected_version.Text.ToString() ,range_expected_name.Text.ToString());
                            StreamWriter nexFile = File.AppendText(path_expected_log);
                            nexFile.WriteLine("={0}= *HOT FIX*", range_expected_version.Text.ToString());
                            nexFile.Close();
                        }
                    }
                    //=============↑==Hot Fixed====================================



                    // 重複issue 
                    string line_temp = "";
                    string Actual_log_temp = path_actual_log;
                    // System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);

                    using (FileStream file = new FileStream(Actual_log_temp, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite))
                    {
                        using (StreamReader Actual_log_Content = new StreamReader(file))
                        {
                            //Do your codes here 
                            while ((line_temp = Actual_log_Content.ReadLine()) != null)
                            {
                                if (line_temp.Contains("*PCI\\VEN_8086&DEV_156F*") || line_temp.Contains("*PCI\\VEN_8086&DEV_156F&SUBSYS_00008086*"))//vPro Lan
                                {
                                    vPro_Lan = true;
                                }
                                if (line_temp.Contains("*PCI\\VEN_10EC&DEV_B822&SUBSYS_29511A3B*"))//AZ_Wireless_check
                                {
                                    AZ_Wireless_check = true;
                                }
                                if (line_temp.Contains("*PCI\\VEN_10EC&DEV_B822&SUBSYS_B82210EC*") || (line_temp.Contains("*PCI\\VEN_10EC&DEV_B822&SUBSYS_54672A3B*")))//GSD Wireless)
                                {
                                    GSD_Wireless_check = true;
                                }
                                if (line_temp.Contains("*usb\\vid_13d3&pid_3531*")) //Bluetooth AZ
                                {
                                    AZ_Bluetooh_check = true;

                                }
                                if (line_temp.Contains("*usb\\vid_0bda&pid_b822*"))//Bluetooth GSD 
                                {
                                    GSD_Bluetooh_check = true;
                                }
                                if (line_temp.Contains("*PCI\\VEN_8086&DEV_9D03&CC_0106*")) //IRST
                                {
                                    IRST_exist = true;
                                }
                                if (line_temp.Contains("*PCI\\VEN_8086&DEV_282A&CC_0104*")) //IRST
                                {
                                    OM_exist = true;
                                }
                            }
                        }
                    }


                    /*
                    //==============↓====Actual Part 2 Special=======================================
                    
                    string path_1 = "SYSTEM\\ControlSet001\\Control\\Class";
                    string path_2 = "";
                    string path_3 = "";
                    Microsoft.Win32.RegistryKey start2 = Microsoft.Win32.Registry.LocalMachine;
                    Microsoft.Win32.RegistryKey programName_1 = start2.OpenSubKey(path_1);

                    foreach (string subKeyName_1 in programName_1.GetSubKeyNames())
                    {
                        path_2 = "SYSTEM\\ControlSet001\\Control\\Class" + "\\" + subKeyName_1;
                        Microsoft.Win32.RegistryKey programName_2 = start2.OpenSubKey(path_2); // SYSTEM\ControlSet001\Control\Class\{e2f84ce7-8efa-411c-aa69-97454ca4cb57} 

                        foreach (string subKeyName_2 in programName_2.GetSubKeyNames())
                        {
                            if (subKeyName_2 != "Properties")
                            {
                                path_3 = path_2 + "\\" + subKeyName_2;
                                Microsoft.Win32.RegistryKey programName_3 = start2.OpenSubKey(path_3); // SYSTEM\ControlSet001\Control\Class\{eec5ad98-8080-425f-922a-dabf3de3f69a}\0000

                                foreach (string valueName in programName_3.GetValueNames()) //讀值
                                {

                                    if ((programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_8086&DEV_5904") //Chipset I3
                                        || (programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_8086&DEV_5914") //Chipset I7
                                        || (programName_3.GetValue(valueName).ToString().ToLower() == "usb\\vid_13d3&pid_3531") //Bluetooth AZ
                                        || (programName_3.GetValue(valueName).ToString().ToLower() == "usb\\vid_0bda&pid_b822") //Bluetooth GSD 
                                        || (programName_3.GetValue(valueName).ToString().ToLower() == "usb\\vid_8087&pid_0a2b&rev_0010")//Bluetooth Intel                
                                        || (programName_3.GetValue(valueName).ToString().ToUpper() == "USB\\VID_27C6&PID_5740&MI_00")//fingerprint
                                        || (programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_8086&DEV_9D03&CC_0106")//IRST
                                        || (programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_8086&DEV_156F")//Intel(R) Ethernet I219-LM
                                        || (programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_8086&DEV_1570")//Intel(R) Ethernet Connection I219-V
                                        || (programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_8086&DEV_156F&SUBSYS_00008086")//Intel(R) Ethernet I219-LM
                                        || (programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_8086&DEV_1570&SUBSYS_00008086")//Intel(R) Ethernet I219-V
                                        || (programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_8086&DEV_9D3A")// ME
                                        || (programName_3.GetValue(valueName).ToString().ToLower() == "acpi\\smo8840")// STMicroelectronics
                                        || (programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_8086&DEV_9D60")//Intel(R) Serial IO
                                        || (programName_3.GetValue(valueName).ToString().ToUpper() == "ACPI\\RTK5445")// UCM
                                        || (programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_10EC&DEV_B822&SUBSYS_29511A3B")//AZ Wireless
                                        || (programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_8086&DEV_24FD&SUBSYS_00108086")//Intel Wireless
                                        || (programName_3.GetValue(valueName).ToString().ToUpper() == "PCI\\VEN_10EC&DEV_B822&SUBSYS_B82210EC")//GSD Wireless (Realtek 8822BE Wireless LAN 802.11ac PCI-E NIC)
                                        )
                                    {
                                        //Console.WriteLine("{0}", path_3);
                                        //string path_current_2 = System.Environment.CurrentDirectory;
                                        //string path_driver_log = path_current_2 + "\\Driver.log";
                                        StreamWriter nexFile = File.AppendText(path_actual_log);
                                        //nexFile.WriteLine("{0}: {1}", valueName, programName_3.GetValue(valueName).ToString());
                                        nexFile.WriteLine("={0}= *{1}*", (string)programName_3.GetValue("DriverVersion"), (string)programName_3.GetValue("MatchingDeviceId"));
                                        nexFile.Close();

                                        //Console.WriteLine("{0,-8}: {1}", valueName,
                                        //    programName_3.GetValue(valueName).ToString());
                                    }
                                }
                            }
                        }


                    } //重複issue
                    */

                    //==============↑====Actual Part 2 Special=======================================

                    for (int x = 1; x <= 105; x++)  // //Report的部分  1,38 ~ 1,77
                    {
                        for (int y = 1; y <= 1; y++)
                        {
                            string expected_verison_in_expected_log = "";
                            string actual_verison_in_actual_log = "";
                            string Name_app_or_driver = "";

                            range_result = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, y];

                            // Console.WriteLine("{0}", range_result.Text.ToString());
                            string check_report = range_result.Text.ToString();

                            if (check_report == "Product Name") // 讀 Report 
                            {                                
                                string Actual_log = path_actual_log;
                                System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                while ((line = Actual_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*PROJECT*"))//讀 Actual.log
                                    {                                       
                                        char key_1 = '=';
                                        actual_verison_in_actual_log = search_in_log(line, key_1);
                                        Excel_WS1.Cells[x, Columns_Report] = actual_verison_in_actual_log;
                                        break; 
                                    }
                                }
                            }
                            else if (check_report == "Tier") // 讀 Report 
                            {
                                string Actual_log = path_actual_log;
                                System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                while ((line = Actual_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*LOCALENAME*"))//讀 Actual.log
                                    {
                                        char key_1 = '=';
                                        actual_verison_in_actual_log = search_in_log(line, key_1);
                                        if (OS_Pro_Home_from_actual_log.Contains("Pro"))
                                        {
                                            if (
                                                  (search_in_log(line, key_1)).Contains("TW")
                                               || (search_in_log(line, key_1)).Contains("HK")
                                               || (search_in_log(line, key_1)).Contains("MY")
                                               || (search_in_log(line, key_1)).Contains("SG")
                                               || (search_in_log(line, key_1)).Contains("TH")
                                               )
                                            {
                                                Excel_WS1.Cells[x, Columns_Report] = "1";
                                                break;
                                            }
                                            else if (
                                                  (search_in_log(line, key_1)).Contains("US")
                                               || (search_in_log(line, key_1)).Contains("CN")
                                               || (search_in_log(line, key_1)).Contains("VN")
                                               || (search_in_log(line, key_1)).Contains("PH")
                                               || (search_in_log(line, key_1)).Contains("ID")
                                               || (search_in_log(line, key_1)).Contains("AE")
                                                    )
                                            {
                                                Excel_WS1.Cells[x, Columns_Report] = "2";
                                                break;
                                            }
                                            else if (
                                                   (search_in_log(line, key_1)).Contains("IN")
                                                || (search_in_log(line, key_1)).Contains("NZ")
                                                || (search_in_log(line, key_1)).Contains("AU")
                                                || (search_in_log(line, key_1)).Contains("CA")
                                                || (search_in_log(line, key_1)).Contains("JP")
                                                    )
                                            {
                                                Excel_WS1.Cells[x, Columns_Report] = "3";
                                                break;
                                            }
                                            else
                                            {
                                                MessageBox.Show("Tier failed.\nPlease report this issue.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                                break;
                                            }
                                        }
                                        else if (OS_Pro_Home_from_actual_log.Contains("Home"))
                                        {
                                            if (   (search_in_log(line, key_1)).Contains("TW")
                                                || (search_in_log(line, key_1)).Contains("HK")
                                                || (search_in_log(line, key_1)).Contains("MY")
                                                || (search_in_log(line, key_1)).Contains("SG")
                                                || (search_in_log(line, key_1)).Contains("TH")
                                               )
                                            {
                                                Excel_WS1.Cells[x, Columns_Report] = "4";
                                                break;
                                            }
                                            else if ((search_in_log(line, key_1)).Contains("US")
                                                  || (search_in_log(line, key_1)).Contains("CN")
                                                  || (search_in_log(line, key_1)).Contains("VN")
                                                  || (search_in_log(line, key_1)).Contains("PH")
                                                  || (search_in_log(line, key_1)).Contains("ID")
                                                  || (search_in_log(line, key_1)).Contains("AE")
                                                  )
                                            {
                                                Excel_WS1.Cells[x, Columns_Report] = "5";
                                                break;
                                            }

                                            else if ((search_in_log(line, key_1)).Contains("IN")
                                                  || (search_in_log(line, key_1)).Contains("NZ")
                                                  || (search_in_log(line, key_1)).Contains("AU")
                                                  || (search_in_log(line, key_1)).Contains("CA")
                                                  || (search_in_log(line, key_1)).Contains("JP")
                                                  )
                                            {
                                                Excel_WS1.Cells[x, Columns_Report] = "6";
                                                break;
                                            }
                                            else
                                            {
                                                MessageBox.Show("Tier failed.\nPlease report this issue.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                                break;
                                            }
                                        }

                                    }
                                    //MessageBox.Show("Tier hey!");
                                }
                            }
                            else if (check_report == "OS") // 讀 Report 
                            {
                                if (OS_Pro_Home_from_actual_log == "Pro 64")
                                {
                                    Excel_WS1.Cells[x, Columns_Report] = "Win10 Pro 64";
                                }
                                else if (OS_Pro_Home_from_actual_log == "Home 64")
                                {
                                    Excel_WS1.Cells[x, Columns_Report] = "Win10 Home 64";
                                }
                            }
                            else if (check_report == "Tester") // 讀 Report 
                            {
                                string Actual_log = path_actual_log;
                                System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                while ((line = Actual_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*TESTER*"))//讀 Actual.log
                                    {
                                        char key_1 = '=';
                                        actual_verison_in_actual_log = search_in_log(line, key_1);
                                        Excel_WS1.Cells[x, Columns_Report] = actual_verison_in_actual_log;
                                        break;
                                    }
                                }
                            }  
                            else if (check_report == "Localization") // 讀 Report 
                            {
                                string Actual_log = path_actual_log;
                                System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                while ((line = Actual_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*LOCALENAME*"))//讀 Actual.log
                                    {
                                        char key_1 = '=';
                                        actual_verison_in_actual_log = search_in_log(line, key_1);
                                        if ((search_in_log(line, key_1)).Contains("HK"))
                                        {
                                            Excel_WS1.Cells[x, Columns_Report] = "Hong Kong";
                                        }
                                        else
                                        { 

                                        switch ((search_in_log(line, key_1)).Remove(0, 3))
                                        {
                                            case "TW":
                                                Excel_WS1.Cells[x, Columns_Report] = "Taiwan";
                                                break;
                                            //case "HK":
                                            //    Excel_WS1.Cells[x, 2] = "Hong Kong";
                                            //    break;
                                            case "MY":
                                                Excel_WS1.Cells[x, Columns_Report] = "Malaysia";
                                                break;
                                            case "SG":
                                                Excel_WS1.Cells[x, Columns_Report] = "Singapore";
                                                break;
                                            case "TH":
                                                Excel_WS1.Cells[x, Columns_Report] = "Thailand";
                                                break;
                                            case "US":
                                                Excel_WS1.Cells[x, Columns_Report] = "United States";
                                                break;
                                            case "CN":
                                                Excel_WS1.Cells[x, Columns_Report] = "China";
                                                break;
                                            case "VN":
                                                Excel_WS1.Cells[x, Columns_Report] = "Vietnam";
                                                break;
                                            case "PH":
                                                Excel_WS1.Cells[x, Columns_Report] = "Philippines";
                                                break;
                                            case "ID":
                                                Excel_WS1.Cells[x, Columns_Report] = "Indonesia";
                                                break;
                                            case "AE":
                                                Excel_WS1.Cells[x, Columns_Report] = "United Arab Emirates";
                                                break;
                                            case "IN":
                                                Excel_WS1.Cells[x, Columns_Report] = "India";
                                                break;
                                            case "NZ":
                                                Excel_WS1.Cells[x, Columns_Report] = "New Zealand";
                                                break;
                                            case "AU":
                                                Excel_WS1.Cells[x, Columns_Report] = "Australia";
                                                break;
                                            case "CA":
                                                Excel_WS1.Cells[x, Columns_Report] = "Canada";
                                                break;
                                            case "JP":
                                                Excel_WS1.Cells[x, Columns_Report] = "Japan";
                                                break;
                                            default:
                                                MessageBox.Show("Not supported locale name found.\nPlease report this issue.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                                break;
                                        }

                                        }

                                        break;
                                    }
                                }
                            }
                            // zh-Hans-HK  => HK-SC
                            // zh-HK       => TC
                            // zh-CN   
                            else if (check_report == "Language") // 讀 Report 
                            {
                                string Actual_log = path_actual_log;
                                System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                while ((line = Actual_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*LOCALENAME*"))// HP
                                    {
                                        char key_1 = '=';
                                        actual_verison_in_actual_log = search_in_log(line, key_1);
                                        //MessageBox.Show( (search_in_log(line, key_1)).Remove(2, 3)  );
                                        if ((search_in_log(line, key_1)) == "zh-Hans-HK")
                                        {
                                            Excel_WS1.Cells[x, Columns_Report] = "SC";
                                        }
                                        else if ((search_in_log(line, key_1)) == "zh-HK")
                                        {
                                            Excel_WS1.Cells[x, Columns_Report] = "TC";
                                        }
                                        else if ((search_in_log(line, key_1)) == "zh-SG")
                                        {
                                            Excel_WS1.Cells[x, Columns_Report] = "SC";
                                        }
                                        else if ((search_in_log(line, key_1)) == "zh-CN")
                                        {
                                            Excel_WS1.Cells[x, Columns_Report] = "SC";
                                        }
                                        else if ((search_in_log(line, key_1)) == "zh-TW")
                                        {
                                            Excel_WS1.Cells[x, Columns_Report] = "TC";
                                        }
                                        else
                                        {                                           
                                            switch ((search_in_log(line, key_1)).Remove(2, 3))
                                            {
                                                case "th":
                                                    Excel_WS1.Cells[x, Columns_Report] = "TH";
                                                    break;

                                                case "en":
                                                    Excel_WS1.Cells[x, Columns_Report] = "EN";
                                                    break;

                                                case "ar":
                                                    Excel_WS1.Cells[x, Columns_Report] = "Arabic";
                                                    break;

                                                case "fr":
                                                    Excel_WS1.Cells[x, Columns_Report] = "FR";
                                                    break;

                                                case "ja":
                                                    Excel_WS1.Cells[x, Columns_Report] = "JP";
                                                    break;

                                                default:
                                                    MessageBox.Show("Not supported language found.\nPlease report this issue.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                                    break;
                                            }
                                        }

                                        break;
                                    }
                                }
                            }
                            else if (check_report == "Test Branding") // 讀 Report 
                            {
                                Excel_WS1.Cells[x, Columns_Report] = "NEXPC";
                            }
                            else if (check_report == "Date") // 讀 Report 
                            {
                                System.DateTime currentTime = new System.DateTime();
                                currentTime = System.DateTime.Now;
                                string date = currentTime.Year.ToString() + "/" + currentTime.Month.ToString() + "/" + currentTime.Day.ToString();
                                Excel_WS1.Cells[x, Columns_Report] = date;
                            }
                            else if (check_report == "BIOS") // 讀 Report 
                            {
                                string Actual_log = path_actual_log;
                                System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                while ((line = Actual_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*BIOS*"))//讀 Actual.log
                                    {
                                        char key_1 = '=';
                                        actual_verison_in_actual_log = search_in_log(line, key_1);
                                        Excel_WS1.Cells[x, Columns_Report] = actual_verison_in_actual_log;
                                        break;
                                    }
                                }
                            }
                            else if (check_report == "Unit Type(SI, PV etc.) / SKU#") // 讀 Report 
                            {
                                int count = SKU_arrylist.Count;
                                //MessageBox.Show(count.ToString());
                                foreach (string sku in SKU_arrylist)
                                {
                                    if (x <= x + count)
                                    {
                                        Excel_WS1.Cells[x, Columns_Report] = sku;
                                        x++;
                                    }
                                    else
                                    {
                                        break;
                                    }
                                    //MessageBox.Show(sku);
                                }

                            }
                            else if (check_report == "NEXSTGO - Backup and Recovery") // 讀 Report 
                            {
                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*NEXSTGO - Backup and Recovery*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*Nexstgo Backup and Recovery*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                            }
                                        }

                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }
                            
                            // no2 46
                            else if (check_report == "NEXSTGO - Hotkey Utilities") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*NEXSTGO - Hotkey Utilities*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*Nexstgo Hotkey Utilities*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                            }
                                        }


                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }
                            // no3 47
                            else if (check_report == "NEXSTGO - Power Manager") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*NEXSTGO - Power Manager*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*Nexstgo Power Manager*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                            }
                                        }


                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }
                            
                            // no4 49
                            else if (check_report == "NEXSTGO - Software Updater") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*NEXSTGO - Software Updater*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*Nexstgo Software Updater*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                            }
                                        }

                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }

                            // no5, 57

                            else if (check_report == "Audio Realtek ALC295") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Audio*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*Realtek High Definition Audio Driver*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                            }
                                        }

                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }
                            //no6, 58
                            else if (check_report == "Bluetooth Azurewave RTL8822BE-CG") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Bluetooth1*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*usb\\vid_13d3&pid_3531*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                            }
                                        }

                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log && AZ_Bluetooh_check == true) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                            AZ_Bluetooh_check = false; //還原
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && AZ_Bluetooh_check == false)
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "N";
                                                Excel_WS1.Cells[x, Columns_Report] = "N";
                                            }
                                            else if (actual_verison_in_actual_log == "" && expected_verison_in_expected_log != "" && AZ_Bluetooh_check == false)
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "N";
                                                Excel_WS1.Cells[x, Columns_Report] = "N";
                                            }
                                            else
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                                Excel_WS1.Cells[x, Columns_Report] = "F";
                                            }
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }
                            
                            //no7, 59
                            else if (check_report == "Bluetooth GSD RTL8822BE-CG") // 讀 Report 
                            {
                                
                                progressBar1.Value = 80;
                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Bluetooth2*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*usb\\vid_0bda&pid_b822*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                            }
                                        }

                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log && GSD_Bluetooh_check == true) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                            GSD_Bluetooh_check = false; //還原
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && GSD_Bluetooh_check == false)
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "N";
                                                Excel_WS1.Cells[x, Columns_Report] = "N";
                                            }
                                            else if (actual_verison_in_actual_log == "" && expected_verison_in_expected_log != "" && GSD_Bluetooh_check == false)
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "N";
                                                Excel_WS1.Cells[x, Columns_Report] = "N";
                                            }
                                            else
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                                Excel_WS1.Cells[x, Columns_Report] = "F";
                                            }
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }

                            //no8, 60
                            else if (check_report == "Bluetooth Intel 8265") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Bluetooth3*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*usb\\vid_8087&pid_0a2b&rev_0010*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);
                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                            }
                                        }

                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            if (actual_verison_in_actual_log == "" && expected_verison_in_expected_log != "")
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "N";
                                                Excel_WS1.Cells[x, Columns_Report] = "N";
                                            }
                                            else
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                                Excel_WS1.Cells[x, Columns_Report] = "F";
                                            }
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }


                            // no9, 61
                            else if (check_report == "Camera Chicony IR Camera CKFHF01") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Camera*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*Realtek PC Camera*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                            }
                                        }

                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            if (actual_verison_in_actual_log == "" && expected_verison_in_expected_log != "")
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "N";
                                                Excel_WS1.Cells[x, Columns_Report] = "N";
                                            }
                                            else
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                                Excel_WS1.Cells[x, Columns_Report] = "F";
                                            }
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }

                            // no10, 62
                            
                            else if (check_report == "Card Reader Realtek RTS5249S") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Card Reader*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*Realtek Card Reader*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                            }
                                        }

                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }


                            // no11 , 63
                            else if (check_report == "Chipset Intel Sunrise Point") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Chipset*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*PCI\\VEN_8086&DEV_5904*") || line.Contains("*PCI\\VEN_8086&DEV_5914*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                            }
                                        }

                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }


                            // no12 , 64
                            else if (check_report == "Fingerprint GooDix GF3208") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Fingerprint*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*USB\\VID_27C6&PID_5740&MI_00*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                            }
                                        }

                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            if (actual_verison_in_actual_log == "" && expected_verison_in_expected_log != "")
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "N";
                                                Excel_WS1.Cells[x, Columns_Report] = "N";
                                            }
                                            else
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                                Excel_WS1.Cells[x, Columns_Report] = "F";
                                            }
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }
                            
                            // no13 , 65
                            else if (check_report == "Graphics AMD R17M-P1-50") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Graphics1*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*UNKNOW*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                            }
                                        }

                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            if (actual_verison_in_actual_log == "" && expected_verison_in_expected_log != "")
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "N";
                                                Excel_WS1.Cells[x, Columns_Report] = "N";
                                            }
                                            else
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                                Excel_WS1.Cells[x, Columns_Report] = "F";
                                            }
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }


                            // no 14, 67            
                            else if (check_report == "Graphics Intel UMA") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Graphics1*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*Intel(R) Processor Graphics*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                            }
                                        }

                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }
                            

                            // no 15, 68            
                            else if (check_report == "IRST Intel AHCI") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*IRST*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*PCI\\VEN_8086&DEV_9D03&CC_0106*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                            }
                                        }

                                        if (IRST_exist == true && OM_exist == false)
                                        {
                                            if ((actual_verison_in_actual_log == expected_verison_in_expected_log)) //比較版本
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                                Excel_WS1.Cells[x, Columns_Report] = "P";
                                            }
                                            else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                            { // 純粹版本不對而已
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                                Excel_WS1.Cells[x, Columns_Report] = "P";
                                            }
                                            else
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                                Excel_WS1.Cells[x, Columns_Report] = "F";
                                            }
                                        }
                                        else if (IRST_exist == false && OM_exist == true)
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Not Support";
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "N";
                                            Excel_WS1.Cells[x, Columns_Report] = "N";
                                        }
                                        else if (IRST_exist == true && OM_exist == true)
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "IRST and OM both exist.";
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        else if (IRST_exist == false && OM_exist == false)
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "IRST and OM both are not found.";
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }

                            // no 16, 69            
                            else if (check_report == "Lan Intel I219") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Lan*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*PCI\\VEN_8086&DEV_156F*") || line.Contains("*PCI\\VEN_8086&DEV_1570*") || line.Contains("*PCI\\VEN_8086&DEV_156F&SUBSYS_00008086*") || line.Contains("*PCI\\VEN_8086&DEV_1570&SUBSYS_00008086*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }

                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }


                            // no 17, 70            
                            else if (check_report == "Management Engine Intel ME Consumer") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Management Engine*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*PCI\\VEN_8086&DEV_9D3A*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }

                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }

                            // no 18, 71         
                            
                            else if (check_report == "Management Engine Intel ME Corporate") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Management Engine*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*PCI\\VEN_8086&DEV_9D3A*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }

                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }
                            
                            // no 20, 73         
                            else if (check_report == "Optane Memory") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Optane Memory*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*PCI\\VEN_8086&DEV_282A&CC_0104*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }
                                        if (IRST_exist == false && OM_exist == true)
                                        {
                                            if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                                Excel_WS1.Cells[x, Columns_Report] = "P";
                                            }
                                            else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                            { // 純粹版本不對而已
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                                Excel_WS1.Cells[x, Columns_Report] = "P";
                                            }
                                        }
                                        else if (IRST_exist == true && OM_exist == false)
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Not Support";
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "N";
                                            Excel_WS1.Cells[x, Columns_Report] = "N";
                                        }
                                        else if (IRST_exist == true && OM_exist == true)
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "IRST and OM both exist.";
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        else if (IRST_exist == false && OM_exist == false)
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "IRST and OM both are not found.";
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }

                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }

                            // no 19, 72         
                            else if (check_report == "Sensor ST G Sensor") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Sensor*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*acpi\\smo8840*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }

                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            if (actual_verison_in_actual_log == "" && expected_verison_in_expected_log != "")
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "N";
                                                Excel_WS1.Cells[x, Columns_Report] = "N";
                                            }
                                            else
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                                Excel_WS1.Cells[x, Columns_Report] = "F";
                                            }
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }
                            
                            // no 20, 73         
                            else if (check_report == "Serial IO Intel Serial I/O") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Serial IO*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*PCI\\VEN_8086&DEV_9D60*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }

                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }
                            
                            // no 20, 73         
                            else if (check_report == "SGX") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*SGX*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*ACPI\\INT0E0C*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }

                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log && vPro_Lan == true) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log && vPro_Lan == true)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if ((actual_verison_in_actual_log == "" && vPro_Lan == false))
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Not Support";
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "N";
                                            Excel_WS1.Cells[x, Columns_Report] = "N";
                                        }
                                        else if ((actual_verison_in_actual_log != "" && vPro_Lan == false))
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment ="It's non vPro Lan but SGX found. " + "Actual:" + actual_verison_in_actual_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        else if ((actual_verison_in_actual_log == "" && vPro_Lan == true))
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "It's vPro Lan but SGX not found. " + "Actual:" + actual_verison_in_actual_log + " Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }

                            // no 21, 74         
                            else if (check_report == "UCM Realtek RTS5450") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*UCM*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*ACPI\\RTK5445*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }

                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }

                            
                            // no 22, 75         
                            else if (check_report == "Wireless LAN Azurewave RTL8822BE-CG") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Wireless LAN1*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*PCI\\VEN_10EC&DEV_B822&SUBSYS_29511A3B*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }

                                        if ((actual_verison_in_actual_log == expected_verison_in_expected_log) && (AZ_Wireless_check == true)) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                            AZ_Wireless_check = false; //還原
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {

                                            if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && AZ_Wireless_check == false)
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "N";
                                                Excel_WS1.Cells[x, Columns_Report] = "N";

                                            }
                                            else if (actual_verison_in_actual_log == "" && expected_verison_in_expected_log != "" && AZ_Wireless_check == false)
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "N";
                                                Excel_WS1.Cells[x, Columns_Report] = "N";
                                            }
                                            else
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                                Excel_WS1.Cells[x, Columns_Report] = "F";
                                            }
                                        }

                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }

                            // no 23, 76         
                            else if (check_report == "Wireless LAN GSD RTL8822BE-CG") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Wireless LAN2*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*PCI\\VEN_10EC&DEV_B822&SUBSYS_B82210EC*") || line.Contains("*PCI\\VEN_10EC&DEV_B822&SUBSYS_54672A3B*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }

                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log && GSD_Wireless_check == true) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                            GSD_Wireless_check = false; //還原
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------add_comment.AddComment(comment);
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {

                                            if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && GSD_Wireless_check == false)
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "N";
                                                Excel_WS1.Cells[x, Columns_Report] = "N";
                                            }
                                            else if (actual_verison_in_actual_log == "" && expected_verison_in_expected_log != "" && GSD_Wireless_check == false)
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "N";
                                                Excel_WS1.Cells[x, Columns_Report] = "N";
                                            }
                                            else
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                                Excel_WS1.Cells[x, Columns_Report] = "F";
                                            }
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }

                            // no 24, 77    
                            else if (check_report == "Wireless LAN Intel 8265") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Wireless LAN3*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*PCI\\VEN_8086&DEV_24FD&SUBSYS_00108086*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }

                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            if (actual_verison_in_actual_log == "" && expected_verison_in_expected_log != "")
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------add_comment.AddComment(comment);
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "N";
                                                Excel_WS1.Cells[x, Columns_Report] = "N";
                                            }
                                            else
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                                Excel_WS1.Cells[x, Columns_Report] = "F";
                                            }
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }

                            //----------------


                            //no25, 42   
                            else if (check_report == "Foxit - Foxit MobilePDF") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Foxit - Foxit MobilePDF*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*FoxitMobilePDF*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }

                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            if (actual_verison_in_actual_log == "" && expected_verison_in_expected_log != "")
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "N";
                                                Excel_WS1.Cells[x, Columns_Report] = "N";
                                            }
                                            else
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                                Excel_WS1.Cells[x, Columns_Report] = "F";
                                            }
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }

                            // no 26, 43    
                            else if (check_report == "Microsoft - LinkedIn") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Microsoft - LinkedIn*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*LinkedIn*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }

                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P"; // APP owner say: At the moment, no need check version.
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F"; // APP owner say: At the moment, no need check version.
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            if (actual_verison_in_actual_log == "" && expected_verison_in_expected_log != "")
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "N"; // APP owner say: At the moment, no need check version.
                                                Excel_WS1.Cells[x, Columns_Report] = "N";
                                            }
                                            else
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "N"; // APP owner say: At the moment, no need check version.
                                                Excel_WS1.Cells[x, Columns_Report] = "F";
                                            }
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }
                            // no 27, 45    
                            
                            else if (check_report == "NEXSTGO - Backup and Recovery UG") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*NEXSTGO - Backup and Recovery UG*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*Nexstgo Backup And Recovery User Guide*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }

                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }
                            // no 28, 48    
                            else if (check_report == "NEXSTGO - Power Manager UG") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*NEXSTGO - Power Manager UG*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*Nexstgo Power Manager User Guide*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }

                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            if (actual_verison_in_actual_log == "" && expected_verison_in_expected_log != "")
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                                Excel_WS1.Cells[x, Columns_Report] = "F";
                                            }
                                            else
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                                Excel_WS1.Cells[x, Columns_Report] = "F";
                                            }
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }

                            // no 29, 50    
                            else if (check_report == "NEXSTGO - Software Updater UG") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*NEXSTGO - Software Updater UG*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*Nexstgo Software Updater User Guide*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }

                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        progressBar2.Value = 80;
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }
                            // no 30, 51    
                            else if (check_report == "NEXSTGO - SW Application Group UG") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*NEXSTGO - SW Application Group UG*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*Nexstgo Software Application Group User Guide*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }

                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            if (actual_verison_in_actual_log == "" && expected_verison_in_expected_log != "")
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                                Excel_WS1.Cells[x, Columns_Report] = "F";
                                            }
                                            else
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                                Excel_WS1.Cells[x, Columns_Report] = "F";
                                            }
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }

                            // no 31, 100   Hot Fix    
                            else if (check_report == "Hotfix") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                string actual_log = path_actual_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*HOT FIX*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉
                                            System.IO.StreamReader actual_log_content = new System.IO.StreamReader(actual_log);
                                            while ((line = actual_log_content.ReadLine()) != null)
                                            {
                                                if (line.Contains("*HOTFIX*")) //讀 actual.log
                                                {
                                                    char key_test = '=';
                                                    actual_verison_in_actual_log = search_in_log(line, key_test);
                                                    
                                                    if (actual_verison_in_actual_log == expected_verison_in_expected_log) // 比對版本
                                                    {
                                                        Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report];
                                                        string comment = "Actual:" + actual_verison_in_actual_log + " Expected:" + expected_verison_in_expected_log;
                                                        add_comment.ClearComments();
                                                        //------------ Font--------------------------------------------
                                                        Excel.Comment comment1 = add_comment.AddComment(comment);
                                                        comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                        comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                        comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                        comment1.Shape.TextFrame.AutoSize = true;
                                                        //------------ Font---------------------------------------------add_comment.AddComment(comment);                                        
                                                        Excel_WS1.Cells[x, Columns_Report] = "P";

                                                        break; //中斷 不用在找了

                                                    }
                                                    else if (actual_verison_in_actual_log != expected_verison_in_expected_log)
                                                    {
                                                        Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report];
                                                        string comment = "Actual:" + actual_verison_in_actual_log + " Expected:" + expected_verison_in_expected_log;
                                                        add_comment.ClearComments();
                                                        //------------ Font--------------------------------------------
                                                        Excel.Comment comment1 = add_comment.AddComment(comment);
                                                        comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                        comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                        comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                        comment1.Shape.TextFrame.AutoSize = true;
                                                        //------------ Font---------------------------------------------add_comment.AddComment(comment);                                        
                                                        Excel_WS1.Cells[x, Columns_Report] = "F";

                                                        

                                                        break; //中斷 不用在找了
                                                    }                                                                                                      
                                                }
                                                                                          
                                            }
                                        expected_log_content.Close();
                                        break; //中斷 不用在找了                                       
                                    }
                                     
                                }
                            }

                            //  Jumpstart Check  
                            else if (check_report == "Jumpstart Check") // 讀 Report 
                            {
                                
                                string actual_log = path_actual_log;
                                System.IO.StreamReader actual_log_content = new System.IO.StreamReader(actual_log);
                                while ((line = actual_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Jumpstart*")) //讀 actual.log
                                    {
                                        if (line.Contains("=PASSED="))
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report];
                                            add_comment.ClearComments();
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (line.Contains("=FAILED="))
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report];
                                            add_comment.ClearComments();
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        else if (line.Contains("=NO RESULT="))
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report];
                                            string comment = "No result found";
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------add_comment.AddComment(comment);                                        
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        else if (line.Contains("=results_summary.txt Not Found="))
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report];
                                            string comment = "results_summary.txt Not Found";
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------add_comment.AddComment(comment);                                        
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                    }
                                }
                            }

                            

                        }
                    }
                    progressBar2.Value = 100;

                    label_Msg_2.Text = "Actual.log_" + Number_Actual_log + " Is Done"; ;
                    //存檔
                    Excel_WB1.Save();
                    Excel_WB_Expect.Save();
                    //關閉及釋放物件
                    ws = null;
                    Excel_WS1 = null;
                    Excel_WS_Expect = null;

                    Excel_WB1.Close();
                    Excel_WB_Expect.Close();

                    Excel_WB1 = null;
                    Excel_WB_Expect = null;


                    Excel_APP1.Quit();
                    Excel_APP_Expected.Quit();

                    Excel_APP1 = null;
                    Excel_APP_Expected = null;
                    progressBar1.Value = 100;
                    //Console.WriteLine("");
                    //Console.WriteLine("All Completed... Press \"Enter\" to exit...");
                    //file_ready = false; // 重置
                    //Console.Read();


                    //MessageBox.Show("All Process Completed.");
                    //Application.Exit();
                    //===========多次 report 回填
                    Number_Actual_log++;
                    path_actual_log = path_current_1 + "\\Harry_Potter_Actual_" + Number_Actual_log + ".log";

                    if (File.Exists(path_actual_log))
                    {
                        button_Start_Test_Result_Compare_Click(sender, e);
                    }
                    else
                    {
                        MessageBox.Show("All Process Completed.");
                        Application.Exit();
                    }
                    //===========多次 report 回填

                }
                else
                {
                    MessageBox.Show("Required file is not ready.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    button_Start_Test_Result_Compare.Visible = true;
                    return;
                }

                


            }
            else if (radioButton_ResultCompare_PP.Checked == true) // Peter Pan
            {
                Properties.Settings set = Properties.Settings.Default;
                Jumpstart_file_name = set.Jumpstart;
                PP_Driver_start = int.Parse(set.PP_Driver_Start);
                PP_Drivr_end = int.Parse(set.PP_Driver_End);
                PP_app_start = int.Parse(set.PP_APP_Start);
                PP_app_end = int.Parse(set.PP_APP_End);
                PP_hotfix = int.Parse(set.PP_Hotfix);

                string search_in_log(string source_line, char find_value)  //處理 "=" 拿掉
                {
                    char charRange = find_value;
                    int startIndex = source_line.IndexOf(charRange);
                    int endIndex = source_line.LastIndexOf(charRange);
                    int length = endIndex - startIndex - 1;
                    return source_line.Substring(startIndex + 1, length);
                }

                string line = "";
                string OS_Pro_Home_from_actual_log = "";
                string path_current_1 = System.Environment.CurrentDirectory;
                string path_request_form = path_current_1 + "\\Peter_Pan_Request_Form.xlsx";
                string path_Report = path_current_1 + "\\Peter_Pan_Report.xlsx";
                string path_actual_log = path_current_1 + "\\Peter_Pan_Actual_"+ Number_Actual_log + ".log";
                string path_expected_log = path_current_1 + "\\Peter_Pan_expected.log";

                DialogResult dc;
                if (File_All_Ready == false)
                {
                    dc = MessageBox.Show("Peter_Pan_Request_Form.xlsx \nPeter_Pan_Report.xlsx \nPeter_Pan_Actual.log\n\nAll are ready?", "Reminder", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                    if (dc == DialogResult.Yes)
                    {
                        File_All_Ready = true;
                    }
                    else if (dc == DialogResult.No)
                    {
                        button_Start_Test_Result_Compare.Visible = true;
                        return;
                    }
                }
                    
                if (File_All_Ready == true)
                {
                    if (!(File.Exists(path_request_form)))
                    {
                        MessageBox.Show("Peter_Pan_Request_Form.xlsx Not Found", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        button_Start_Test_Result_Compare.Visible = true;
                        return;
                    }
                    if (!(File.Exists(path_Report)))
                    {
                        MessageBox.Show("Peter_Pan_Report.xlsx Not Found", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        button_Start_Test_Result_Compare.Visible = true;
                        return;
                    }
                    if (!(File.Exists(path_actual_log)))
                    {
                        MessageBox.Show("Peter_Pan_Actual.log Not Found", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        button_Start_Test_Result_Compare.Visible = true;
                        return;
                    }
                    progressBar2.Visible = true;
                    label_Msg_2.Text = "Actual.log_" + Number_Actual_log + " Is In Progress";

                    if (File.Exists(path_expected_log)) // Expected.log already exist ?
                    {
                        File.Delete(path_expected_log);
                    }
                    

                    //應用程序
                    Excel.Application Excel_APP1 = new Excel.Application();
                    Excel.Application Excel_APP_Expected = new Excel.Application();
                    //檔案
                    Excel.Workbook Excel_WB1 = Excel_APP1.Workbooks.Open(path_Report);
                    Excel.Workbook Excel_WB_Expect = Excel_APP_Expected.Workbooks.Open(path_request_form);
                    //工作表
                    // Excel.Worksheet Excel_WS1 = new Excel.Worksheet();

                    //自動改sheet name
                    Excel.Worksheet ws = (Excel.Worksheet)Excel_APP_Expected.Worksheets.get_Item(1);
                    ws.Name = "PAN_Image_Build_Request_Form_";
                    //自動改sheet name

                    // Get *OS* from actual.log
                    using (FileStream file = new FileStream(path_actual_log, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite))
                    {
                        string line_temp_2 = "";
                        using (StreamReader Actual_log_Content = new StreamReader(file))
                        {
                            //Do your codes here 
                            while ((line_temp_2 = Actual_log_Content.ReadLine()) != null)
                            {
                                if (line_temp_2.Contains("*OS*"))
                                {
                                    char key_1 = '=';
                                    string version_Image = search_in_log(line_temp_2, key_1);
                                    OS_Pro_Home_from_actual_log = version_Image;
                                }
                            }

                        }
                    }

                    if (OS_Pro_Home_from_actual_log == "Pro 64")
                    {
                        Columns_Report_Pro += 3;
                        Columns_Report = Columns_Report_Pro;
                    }
                    else if (OS_Pro_Home_from_actual_log == "Home 64")
                    {
                        Columns_Report_Home += 3;
                        Columns_Report = Columns_Report_Home;
                    }

                    Excel.Worksheet Excel_WS1 = (Excel.Worksheet)Excel_WB1.Sheets[OS_Pro_Home_from_actual_log]; // Result.xlsx
                    Excel.Worksheet Excel_WS_Expect = (Excel.Worksheet)Excel_WB_Expect.Sheets["PAN_Image_Build_Request_Form_"];
                    Excel.Worksheet Excel_WS_Peter_PVT = (Excel.Worksheet)Excel_WB1.Sheets[textBox_Spec_SheetName_Peter.Text];
                    Excel.Worksheet Excel_WS_Pan_PVT = (Excel.Worksheet)Excel_WB1.Sheets[textBox_Spec_SheetName_Pan.Text];
                    // 測試中....讀取
                    Microsoft.Office.Interop.Excel.Range range_result;
                    Microsoft.Office.Interop.Excel.Range range_expected_name;
                    Microsoft.Office.Interop.Excel.Range range_expected_version;
                    Microsoft.Office.Interop.Excel.Range sku_name;

                    //========================= For Image partnumber ================


                    string line_temp = "";
                    using (FileStream file = new FileStream(path_actual_log, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite))
                    {
                        using (StreamReader Actual_log_Content = new StreamReader(file))
                        {
                            //Do your codes here 
                            while (( line_temp = Actual_log_Content.ReadLine()) != null)
                            {
                                if (line_temp.Contains("*IMAGE*"))
                                {
                                    char key_1 = '=';
                                    string version_Image = search_in_log(line_temp, key_1);
                                    Excel_WS1.Cells[2, Columns_Report] = version_Image;
                                }
                            }
                            
                        }
                    }
                    //========================= For Image partnumber ================

                    //==========↓ 處理SKU number in Actual.log===============
                    string Which_SKU = "";
                    string SKU_Number_Actual_Log = "";
                    //string Actual_log = path_actual_log;
                    System.IO.StreamReader Actual_log_content_sku_number = new System.IO.StreamReader(path_actual_log);
                    while ((line = Actual_log_content_sku_number.ReadLine()) != null)
                    {
                        if ( line.Contains("*Peter SKU*") )//讀 Actual.log
                        {
                            Which_SKU = "Peter";
                            char key_1 = '=';
                            SKU_Number_Actual_Log = search_in_log(line, key_1);
                            Actual_log_content_sku_number.Close();
                            break; //找到, 不用再找了
                        }
                        else if ( line.Contains("*Pan SKU*"))//讀 Actual.log
                        {
                            Which_SKU = "Pan";
                            char key_1 = '=';
                            SKU_Number_Actual_Log = search_in_log(line, key_1);
                            Actual_log_content_sku_number.Close();
                            break; //找到, 不用再找了
                        }
                    }
                    Actual_log_content_sku_number.Close();
                    //Actual_log_content_sku_number.Close();
                    //==========↑ 處理SKU number in Actual.log===============

                    //==================SKU=======PeterPan==================
                    int sku_number;
                    ArrayList SKU_arrylist = new ArrayList();
                    int column = 0;
                    if (Which_SKU == "Peter")
                    {
                        try
                        {
                            sku_number = int.Parse(SKU_Number_Actual_Log.Remove(1, SKU_Number_Actual_Log.Length - 1));
                            SKU_arrylist.Add("Peter / SKU" + SKU_Number_Actual_Log);
                            switch (sku_number)
                            {
                                case 1:  // SKU 幾
                                    column = 2;
                                    break;
                                case 2:
                                    column = 3;
                                    break;
                                case 3:
                                    column = 4;
                                    break;
                                case 4:
                                    column = 5;
                                    break;
                                case 5:
                                    column = 6;
                                    break;
                                case 6:
                                    column = 7;
                                    break;
                                default:
                                    MessageBox.Show("SKU number is out of range on Peter unit.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    //存檔
                                    Excel_WB1.Save();
                                    Excel_WB_Expect.Save();
                                    //關閉及釋放物件
                                    ws = null;
                                    Excel_WS1 = null;
                                    Excel_WS_Expect = null;
                                    Excel_WB1.Close();
                                    Excel_WB_Expect.Close();
                                    Excel_WB1 = null;
                                    Excel_WB_Expect = null;
                                    Excel_APP1.Quit();
                                    Excel_APP_Expected.Quit();
                                    Excel_APP1 = null;
                                    Excel_APP_Expected = null;
                                    Application.Exit();
                                    break;
                            }

                            for (int x = column; x <= column; x++)
                                for (int y = int.Parse(textBox_Spec_rows_Peter_Start.Text); y <= int.Parse(textBox_Spec_rows_Peter_End.Text); y++)
                                {
                                    sku_name = (Microsoft.Office.Interop.Excel.Range)Excel_WS_Peter_PVT.Cells[y, x];
                                    SKU_arrylist.Add(sku_name.Text.ToString());
                                    // MessageBox.Show(sku_name.Text.ToString());
                                }
                        }
                        catch
                        {
                            MessageBox.Show("Invalid SKU number on Peter.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            //存檔
                            Excel_WB1.Save();
                            Excel_WB_Expect.Save();
                            //關閉及釋放物件
                            ws = null;
                            Excel_WS1 = null;
                            Excel_WS_Expect = null;
                            Excel_WB1.Close();
                            Excel_WB_Expect.Close();
                            Excel_WB1 = null;
                            Excel_WB_Expect = null;
                            Excel_APP1.Quit();
                            Excel_APP_Expected.Quit();
                            Excel_APP1 = null;
                            Excel_APP_Expected = null;
                            Application.Exit();
                        }


                    }
                    else if (Which_SKU == "Pan")
                    {
                        try
                        {
                            sku_number = int.Parse(SKU_Number_Actual_Log.Remove(1, SKU_Number_Actual_Log.Length - 1));
                            SKU_arrylist.Add("Pan / SKU" + SKU_Number_Actual_Log);
                            switch (sku_number)
                            {
                                case 1:  // SKU 幾
                                    column = 2;
                                    break;
                                case 2:
                                    column = 3;
                                    break;
                                case 3:
                                    column = 4;
                                    break;
                                case 4:
                                    column = 5;
                                    break;
                                case 5:
                                    column = 6;
                                    break;
                                case 6:
                                    column = 7;
                                    break;
                                default:
                                    MessageBox.Show("SKU number is out of range on Pan unit.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    //存檔
                                    Excel_WB1.Save();
                                    Excel_WB_Expect.Save();
                                    //關閉及釋放物件
                                    ws = null;
                                    Excel_WS1 = null;
                                    Excel_WS_Expect = null;
                                    Excel_WB1.Close();
                                    Excel_WB_Expect.Close();
                                    Excel_WB1 = null;
                                    Excel_WB_Expect = null;
                                    Excel_APP1.Quit();
                                    Excel_APP_Expected.Quit();
                                    Excel_APP1 = null;
                                    Excel_APP_Expected = null;
                                    Application.Exit();
                                    break;
                            }
                            for (int x = column; x <= column; x++)
                                for (int y = int.Parse(textBox_Spec_rows_Pan_Start.Text); y <= int.Parse(textBox_Spec_rows_Pan_End.Text); y++)
                                {
                                    sku_name = (Microsoft.Office.Interop.Excel.Range)Excel_WS_Pan_PVT.Cells[y, x];
                                    SKU_arrylist.Add(sku_name.Text.ToString());
                                    // MessageBox.Show(sku_name.Text.ToString());
                                }
                        }
                        catch
                        {
                            MessageBox.Show("Invalid SKU number on Pan.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            //存檔
                            Excel_WB1.Save();
                            Excel_WB_Expect.Save();
                            //關閉及釋放物件
                            ws = null;
                            Excel_WS1 = null;
                            Excel_WS_Expect = null;
                            Excel_WB1.Close();
                            Excel_WB_Expect.Close();
                            Excel_WB1 = null;
                            Excel_WB_Expect = null;
                            Excel_APP1.Quit();
                            Excel_APP_Expected.Quit();
                            Excel_APP1 = null;
                            Excel_APP_Expected = null;
                            Application.Exit();
                        }
                    }
                    //==================SKU======PeterPan===================

                    //===============↓==Expected=====================================
                    int check_for_Graphics = 1;
                    int check_for_BT = 1;
                    int check_for_WLAN = 1;
                    for (int x = PP_Driver_start; x <= PP_Drivr_end; x++)  // Requested Form的上半部 2,2 ~ 2,11     6,2 ~ 6,11
                    {
                        for (int y = 2; y <= 2; y++)
                        {
                            for (int z = 6; z <= 6; z++)
                            {
                                range_expected_name = (Microsoft.Office.Interop.Excel.Range)Excel_WS_Expect.Cells[x, y];
                                range_expected_version = (Microsoft.Office.Interop.Excel.Range)Excel_WS_Expect.Cells[x, z];
                                //aa = range_expected_name.Text.ToString();
                                //Console.WriteLine("=Version={0}=Version=  =Name={1}=Name=", range_expected_version.Text.ToString() ,range_expected_name.Text.ToString());
                                StreamWriter nexFile = File.AppendText(path_expected_log);
                                if (range_expected_name.Text.ToString() == "Bluetooth")
                                {
                                    string temp = range_expected_name.Text.ToString();
                                    temp = temp + check_for_BT.ToString();
                                    nexFile.WriteLine("={0}= *{1}*", range_expected_version.Text.ToString(), temp);
                                    nexFile.Close();
                                    if (check_for_BT == 3)
                                    {
                                        check_for_BT = 1;
                                    }
                                    check_for_BT++;
                                    continue;
                                }

                                if (range_expected_name.Text.ToString() == "Graphics")
                                {
                                    string temp = range_expected_name.Text.ToString();
                                    temp = temp + check_for_Graphics.ToString();
                                    nexFile.WriteLine("={0}= *{1}*", range_expected_version.Text.ToString(), temp);
                                    nexFile.Close();
                                    if (check_for_Graphics == 2)
                                    {
                                        check_for_Graphics = 1;
                                    }
                                    check_for_Graphics++;
                                    continue;
                                }

                                if (range_expected_name.Text.ToString() == "Wireless LAN")
                                {
                                    string temp = range_expected_name.Text.ToString();
                                    temp = temp + check_for_WLAN.ToString();
                                    nexFile.WriteLine("={0}= *{1}*", range_expected_version.Text.ToString(), temp);
                                    nexFile.Close();
                                    if (check_for_WLAN == 3)
                                    {
                                        check_for_WLAN = 1;
                                    }
                                    check_for_WLAN++;
                                    continue;
                                }


                                nexFile.WriteLine("={0}= *{1}*", range_expected_version.Text.ToString(), range_expected_name.Text.ToString());
                                nexFile.Close();
                            }
                        }
                    }

                    for (int x = PP_app_start; x <= PP_app_end; x++)  // Requested Form的下半部  2,12 ~ 2,23  and 4,12 ~ 4,23
                    {
                        for (int y = 2; y <= 2; y++)
                        {
                            for (int z = 4; z <= 4; z++)
                            {
                                range_expected_name = (Microsoft.Office.Interop.Excel.Range)Excel_WS_Expect.Cells[x, y];
                                range_expected_version = (Microsoft.Office.Interop.Excel.Range)Excel_WS_Expect.Cells[x, z];
                                //aa = range_expected_name.Text.ToString();
                                //Console.WriteLine("=Version={0}=Version=  =Name={1}=Name=", range_expected_version.Text.ToString() ,range_expected_name.Text.ToString());
                                StreamWriter nexFile = File.AppendText(path_expected_log);
                                string check_v = range_expected_version.Text.ToString();
                                if (check_v.Contains("v"))
                                {
                                    //Console.WriteLine(header.Trim(new Char[] { 'v' }));
                                    // 處理 如果版本多出 v
                                    nexFile.WriteLine("={0}= *{1}*", check_v.Trim(new Char[] { 'v' }), range_expected_name.Text.ToString());
                                    nexFile.Close();
                                }
                                else
                                {
                                    nexFile.WriteLine("={0}= *{1}*", range_expected_version.Text.ToString(), range_expected_name.Text.ToString());
                                    nexFile.Close();
                                }
                            }
                        }
                    }
                    //==============↑====Expected=======================================
                    progressBar2.Value = 60;
                    //=============↓==Hot Fixed====================================
                    for (int x = PP_hotfix; x <= PP_hotfix; x++)
                    {
                        for (int y = 3; y <= 3; y++)
                        {
                            range_expected_version = (Microsoft.Office.Interop.Excel.Range)Excel_WS_Expect.Cells[x, y];
                            //aa = range_expected_name.Text.ToString();
                            //Console.WriteLine("=Version={0}=Version=  =Name={1}=Name=", range_expected_version.Text.ToString() ,range_expected_name.Text.ToString());
                            StreamWriter nexFile = File.AppendText(path_expected_log);
                            nexFile.WriteLine("={0}= *HOT FIX*", range_expected_version.Text.ToString());
                            nexFile.Close();
                        }
                    }
                    //=============↑==Hot Fixed====================================




                    for (int x = 1; x <= 105; x++)  // //Report的部分  1,38 ~ 1,77
                    {
                        for (int y = 1; y <= 1; y++)
                        {
                            
                            string expected_verison_in_expected_log = "";
                            string actual_verison_in_actual_log = "";
                            string Name_app_or_driver = "";
                            range_result = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, y];
                            string check_report = range_result.Text.ToString();
                            /*
                            string search_in_log(string source_line, char find_value)  //處理 "=" 拿掉
                            {
                                char charRange = find_value;
                                int startIndex = source_line.IndexOf(charRange);
                                int endIndex = source_line.LastIndexOf(charRange);
                                int length = endIndex - startIndex - 1;
                                return source_line.Substring(startIndex + 1, length);
                            }
                            */


                            
                            if (check_report == "Product Name") // 讀 Report 
                            {
                                string Actual_log = path_actual_log;
                                System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                while ((line = Actual_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*PROJECT*"))//讀 Actual.log
                                    {
                                        char key_1 = '=';
                                        actual_verison_in_actual_log = search_in_log(line, key_1);
                                        Excel_WS1.Cells[x, Columns_Report] = actual_verison_in_actual_log;
                                        break; //找到, 不用再找了
                                    }
                                }
                            }                            
                            else if (check_report == "Tier") // 讀 Report 
                            {
                                string Actual_log = path_actual_log;
                                System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                while ((line = Actual_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*LOCALENAME*"))//讀 Actual.log
                                    {
                                        char key_1 = '=';
                                        actual_verison_in_actual_log = search_in_log(line, key_1);
                                        if (OS_Pro_Home_from_actual_log.Contains("Pro"))
                                        {
                                            if (                                              
                                                  (search_in_log(line, key_1)).Contains("HK")
                                               || (search_in_log(line, key_1)).Contains("TW")
                                               || (search_in_log(line, key_1)).Contains("SG")
                                               )
                                            {
                                                Excel_WS1.Cells[x, Columns_Report] = "1";
                                                break;
                                            }
                                            else if (
                                                  (search_in_log(line, key_1)).Contains("MY")
                                               || (search_in_log(line, key_1)).Contains("TH")
                                               || (search_in_log(line, key_1)).Contains("PH")
                                               || (search_in_log(line, key_1)).Contains("CN")
                                               || (search_in_log(line, key_1)).Contains("ID")
                                               || (search_in_log(line, key_1)).Contains("VN")
                                                    )
                                            {
                                                Excel_WS1.Cells[x, Columns_Report] = "2";
                                                break;
                                            }
                                            else if (
                                                   (search_in_log(line, key_1)).Contains("US")
                                                || (search_in_log(line, key_1)).Contains("AE")
                                                || (search_in_log(line, key_1)).Contains("IN")
                                                    )
                                            {
                                                Excel_WS1.Cells[x, Columns_Report] = "3";
                                                break;
                                            }
                                            else
                                            {
                                                MessageBox.Show("Tier failed.\nPlease report this issue.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                                break;

                                            }
                                        }
                                        else if ( (OS_Pro_Home_from_actual_log.Contains("Home")) )
                                        {
                                            if (  (search_in_log(line, key_1)).Contains("HK")
                                               || (search_in_log(line, key_1)).Contains("TW")
                                               || (search_in_log(line, key_1)).Contains("SG")
                                               || (search_in_log(line, key_1)).Contains("MY")
                                               || (search_in_log(line, key_1)).Contains("TH")
                                               )
                                            {
                                                Excel_WS1.Cells[x, Columns_Report] = "3";
                                                break;
                                            }
                                            else if (  (search_in_log(line, key_1)).Contains("PH")
                                                    || (search_in_log(line, key_1)).Contains("CN")
                                                    || (search_in_log(line, key_1)).Contains("ID")
                                                    || (search_in_log(line, key_1)).Contains("VN")
                                                    || (search_in_log(line, key_1)).Contains("US")
                                                    || (search_in_log(line, key_1)).Contains("AE")
                                                    || (search_in_log(line, key_1)).Contains("IN")
                                                    )
                                            {
                                                Excel_WS1.Cells[x, Columns_Report] = "4";
                                                break;
                                            }
                                            else
                                            {
                                                MessageBox.Show("Tier failed.\nPlease report this issue.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                                break;

                                            }

                                        }

                                    }
                                    //MessageBox.Show("Tier hey!");
                                }
                            }                           
                            else if (check_report == "OS") // 讀 Report 
                            {
                                if (OS_Pro_Home_from_actual_log == "Pro 64")
                                {
                                    Excel_WS1.Cells[x, Columns_Report] = "Win10 Pro 64";
                                }
                                else if (OS_Pro_Home_from_actual_log == "Home 64")
                                {
                                    Excel_WS1.Cells[x, Columns_Report] = "Win10 Home 64";
                                }
                            }
                            else if (check_report == "Tester") // 讀 Report 
                            {
                                string Actual_log = path_actual_log;
                                System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                while ((line = Actual_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*TESTER*"))//讀 Actual.log
                                    {                                       
                                        char key_1 = '=';
                                        actual_verison_in_actual_log = search_in_log(line, key_1);
                                        Excel_WS1.Cells[x, Columns_Report] = actual_verison_in_actual_log;
                                        break; //找到, 不用再找了
                                    }
                                }
                            }
                            else if (check_report == "Localization") // 讀 Report 
                            {
                                string Actual_log = path_actual_log;
                                System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                while ((line = Actual_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*LOCALENAME*"))//讀 Actual.log
                                    {
                                        char key_1 = '=';
                                        actual_verison_in_actual_log = search_in_log(line, key_1);
                                        switch ((search_in_log(line, key_1)).Remove(0, 3))
                                        {
                                            case "TW":
                                                Excel_WS1.Cells[x, Columns_Report] = "Taiwan";
                                                break;
                                            case "HK":
                                                Excel_WS1.Cells[x, Columns_Report] = "Hong Kong";
                                                break;
                                            case "MY":
                                                Excel_WS1.Cells[x, Columns_Report] = "Malaysia";
                                                break;
                                            case "SG":
                                                Excel_WS1.Cells[x, Columns_Report] = "Singapore";
                                                break;
                                            case "TH":
                                                Excel_WS1.Cells[x, Columns_Report] = "Thailand";
                                                break;
                                            case "US":
                                                Excel_WS1.Cells[x, Columns_Report] = "United States";
                                                break;
                                            case "CN":
                                                Excel_WS1.Cells[x, Columns_Report] = "China";
                                                break;
                                            case "VN":
                                                Excel_WS1.Cells[x, Columns_Report] = "Vietnam";
                                                break;
                                            case "PH":
                                                Excel_WS1.Cells[x, Columns_Report] = "Philippines";
                                                break;
                                            case "ID":
                                                Excel_WS1.Cells[x, Columns_Report] = "Indonesia";
                                                break;
                                            case "AE":
                                                Excel_WS1.Cells[x, Columns_Report] = "United Arab Emirates";
                                                break;
                                            case "IN":
                                                Excel_WS1.Cells[x, Columns_Report] = "India";
                                                break;
                                            case "NZ":
                                                Excel_WS1.Cells[x, Columns_Report] = "New Zealand";
                                                break;
                                            case "AU":
                                                Excel_WS1.Cells[x, Columns_Report] = "Australia";
                                                break;
                                            case "CA":
                                                Excel_WS1.Cells[x, Columns_Report] = "Canada";
                                                break;
                                            case "JP":
                                                Excel_WS1.Cells[x, Columns_Report] = "Japan";
                                                break;
                                            default:                                                
                                                MessageBox.Show("Not supported locale name found.\nPlease report this issue.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                                break;
                                        }
                                         
                                        break;
                                    }
                                }
                            }                           
                            else if (check_report == "Language") // 讀 Report 
                            {
                                string Actual_log = path_actual_log;
                                System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                while ((line = Actual_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*LOCALENAME*"))// HP
                                    {
                                        char key_1 = '=';
                                        actual_verison_in_actual_log = search_in_log(line, key_1);
                                        //MessageBox.Show( (search_in_log(line, key_1)).Remove(2, 3)  );
                                        if ((search_in_log(line, key_1)) == "zh-Hans-HK")
                                        {
                                            Excel_WS1.Cells[x, Columns_Report] = "CH";
                                        }
                                        else if ((search_in_log(line, key_1)) == "zh-HK")
                                        {
                                            Excel_WS1.Cells[x, Columns_Report] = "TZ";
                                        }
                                        else if ((search_in_log(line, key_1)) == "zh-SG")
                                        {
                                            Excel_WS1.Cells[x, Columns_Report] = "CH";
                                        }
                                        else if ((search_in_log(line, key_1)) == "zh-CN")
                                        {
                                            Excel_WS1.Cells[x, Columns_Report] = "CH";
                                        }
                                        else if ((search_in_log(line, key_1)) == "zh-TW")
                                        {
                                            Excel_WS1.Cells[x, Columns_Report] = "TW";
                                        }
                                        else
                                        {
                                            switch ((search_in_log(line, key_1)).Remove(2, 3))
                                            {
                                                case "th":
                                                    Excel_WS1.Cells[x, Columns_Report] = "TH";
                                                    break;

                                                case "en":
                                                    Excel_WS1.Cells[x, Columns_Report] = "EN";
                                                    break;

                                                case "ar":
                                                    Excel_WS1.Cells[x, Columns_Report] = "Arabic";
                                                    break;

                                                case "fr":
                                                    Excel_WS1.Cells[x, Columns_Report] = "FR";
                                                    break;

                                                case "ja":
                                                    Excel_WS1.Cells[x, Columns_Report] = "JP";
                                                    break;

                                                default:
                                                    MessageBox.Show("Not supported language found.\nPlease report this issue.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                                    break;
                                            }
                                        }

                                        break;
                                    }
                                }
                            }
                            
                            else if (check_report == "Test Branding") // 讀 Report 
                            {
                                Excel_WS1.Cells[x, Columns_Report] = "NEXPC";
                            }
                            else if (check_report == "Date") // 讀 Report 
                            {
                                System.DateTime currentTime = new System.DateTime();
                                currentTime = System.DateTime.Now;
                                string date = currentTime.Year.ToString() + "/" + currentTime.Month.ToString() + "/" + currentTime.Day.ToString();
                                Excel_WS1.Cells[x, Columns_Report] = date;
                            }
                            else if (check_report == "BIOS") // 讀 Report 
                            {
                                string Actual_log = path_actual_log;
                                System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                while ((line = Actual_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*BIOS*"))//讀 Actual.log
                                    {
                                        char key_1 = '=';
                                        actual_verison_in_actual_log = search_in_log(line, key_1);
                                        Excel_WS1.Cells[x, Columns_Report] = actual_verison_in_actual_log;
                                        break;
                                    }
                                }
                            }
                            else if (check_report == "Unit Type(SI, PV etc.) / SKU#") // 讀 Report 
                            {
                                int count = SKU_arrylist.Count;
                                //MessageBox.Show(count.ToString());
                                foreach (string sku in SKU_arrylist)
                                {
                                    if (x <= x + count)
                                    {
                                        Excel_WS1.Cells[x, Columns_Report] = sku;
                                        x++;
                                    }
                                    else
                                    {
                                        break;
                                    }
                                    //MessageBox.Show(sku);
                                }

                            }
                            // no1 , 38
                            else if (check_report == "Clevo - Airplane Mode") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Clevo - Airplane Mode*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*acpi\\ven_pnp&dev_c000*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }

                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }
                            
                            // no2 , 39
                            else if (check_report == "Clevo - Control Center") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Clevo - Control Center*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*Control Center"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }


                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }

                            
                            // no3 , 42
                            else if (check_report == "NEXSTGO - Backup and Recovery") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*NEXSTGO - Backup and Recovery*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*Nexstgo Backup and Recovery*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }


                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            if (actual_verison_in_actual_log == "" && expected_verison_in_expected_log != "")
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "N";
                                                Excel_WS1.Cells[x, Columns_Report] = "N";
                                            }
                                            else
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                                Excel_WS1.Cells[x, Columns_Report] = "F";
                                            }

                                        }

                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }



                            // no4 , 44
                            else if (check_report == "NEXSTGO - Software Updater") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*NEXSTGO - Software Updater*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*Nexstgo Software Updater*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }


                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            if (actual_verison_in_actual_log == "" && expected_verison_in_expected_log != "")
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "N";
                                                Excel_WS1.Cells[x, Columns_Report] = "N";
                                            }
                                            else
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                                Excel_WS1.Cells[x, Columns_Report] = "F";
                                            }
                                        }
                                        progressBar2.Value = 80;
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }

                            // no5 , 51
                            else if (check_report == "Realtek High Definition Audio") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Audio*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*Realtek High Definition Audio Driver*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }


                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }
                            
                            // no6 , 52
                            else if (check_report == "Intel(R) Wireless Bluetooth(R) 8260") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Bluetooth1*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*usb\\vid_8087&pid_0aa7*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }


                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------add_comment.AddComment(comment);
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }

                            // no7 , 53
                            else if (check_report == "Realtek Card Reader") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Card Reader*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*Realtek Card Reader*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }


                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }

                            // no8 , 54
                            else if (check_report == "Intel(R) 100 Series/C230 Series Chipset Family") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Chipset*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*PCI\\VEN_8086&DEV_5904*") || line.Contains("*PCI\\VEN_8086&DEV_5914*") )//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }


                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }

                            // no9 , 55
                            else if (check_report == "Intel(R) HD Graphics 620") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Graphics1*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*Intel(R) Processor Graphics*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }


                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }


                            // no10 , 56
                            else if (check_report == "Intel® RST") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*IRST*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*PCI\\VEN_8086&DEV_9D03&CC_0106*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }


                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }

                            // no11 , 57
                            else if (check_report == "Realtek RTL8411B Ethernet") // 讀 Report 
                            {
                                progressBar1.Value = 80;
                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Lan*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*PCI\\VEN_10EC&DEV_8168&SUBSYS_31071DC2&REV_12*") || line.Contains("*PCI\\VEN_10EC&DEV_8168&SUBSYS_31061DC2&REV_12*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }


                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }

                            // no12 , 58
                            else if (check_report == "Intel(R) Management Engine Interface") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Management Engine*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*PCI\\VEN_8086&DEV_9D3A*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }


                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }

                            // no13 , 59
                            else if (check_report == "Synaptics Touchpad") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Touchpad*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*acpi\\syn1222*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }


                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            if (actual_verison_in_actual_log == "" && expected_verison_in_expected_log != "")
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "N";
                                                Excel_WS1.Cells[x, Columns_Report] = "N";
                                            }
                                            else
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                                Excel_WS1.Cells[x, Columns_Report] = "F";
                                            }
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }


                            // no14 , 60
                            else if (check_report == "Intel(R) Dual Band Wireless - AC 3168") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Wireless LAN1*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*PCI\\VEN_8086&DEV_24FB&SUBSYS_21108086*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }


                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }

                            // no 15, 40                        
                            else if (check_report == "Foxit - Foxit MobilePDF") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Foxit - Foxit MobilePDF*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*FoxitMobilePDF*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }

                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            if (actual_verison_in_actual_log == "" && expected_verison_in_expected_log != "")
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "N";
                                                Excel_WS1.Cells[x, Columns_Report] = "N";
                                            }
                                            else
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                                Excel_WS1.Cells[x, Columns_Report] = "F";
                                            }
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }
                            // no 16, 41                      
                            else if (check_report == "Microsoft - LinkedIn") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Microsoft - LinkedIn*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*LinkedIn*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }

                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "N"; // APP owner say: No need check version
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "N"; // APP owner say: No need check version
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            if (actual_verison_in_actual_log == "" && expected_verison_in_expected_log != "")
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "N";
                                                Excel_WS1.Cells[x, Columns_Report] = "N";
                                            }
                                            else
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "N";
                                                Excel_WS1.Cells[x, Columns_Report] = "F";
                                            }
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }

                            // no 17, 43        
                            else if (check_report == "NEXSTGO - Backup and Recovery UG") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*NEXSTGO - Backup and Recovery UG*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*Nexstgo Backup And Recovery User Guide*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }

                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------add_comment.AddComment(comment);
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            if (actual_verison_in_actual_log == "" && expected_verison_in_expected_log != "")
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "N";
                                                Excel_WS1.Cells[x, Columns_Report] = "N";
                                            }
                                            else
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                                Excel_WS1.Cells[x, Columns_Report] = "F";
                                            }
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }

                            // no 18, 45      
                            else if (check_report == "NEXSTGO - Software Updater UG") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);
                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*NEXSTGO - Software Updater UG*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉


                                        string Actual_log = path_actual_log;
                                        System.IO.StreamReader Actual_log_content = new System.IO.StreamReader(Actual_log);
                                        while ((line = Actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*Nexstgo Software Updater User Guide*"))//讀 Actual.log
                                            {
                                                Name_app_or_driver = line;
                                                char key_1 = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_1);

                                                char key_for_name = '*';
                                                Console.WriteLine("{0}, Expected:{1}, Actual:{2}", search_in_log(Name_app_or_driver, key_for_name), expected_verison_in_expected_log, actual_verison_in_actual_log);
                                                break; // workaround
                                            }
                                        }

                                        if (actual_verison_in_actual_log == expected_verison_in_expected_log) //比較版本
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "P";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (actual_verison_in_actual_log != "" && expected_verison_in_expected_log != "" && actual_verison_in_actual_log != expected_verison_in_expected_log)
                                        { // 純粹版本不對而已
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                            string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------
                                            Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else
                                        {
                                            if (actual_verison_in_actual_log == "" && expected_verison_in_expected_log != "")
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "N";
                                                Excel_WS1.Cells[x, Columns_Report] = "N";
                                            }
                                            else
                                            {
                                                Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report + 1];
                                                string comment = "Actual:" + actual_verison_in_actual_log + " " + "Expected:" + expected_verison_in_expected_log;
                                                add_comment.ClearComments();
                                                //------------ Font--------------------------------------------
                                                Excel.Comment comment1 = add_comment.AddComment(comment);
                                                comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                comment1.Shape.TextFrame.AutoSize = true;
                                                //------------ Font---------------------------------------------
                                                Excel_WS1.Cells[x, Columns_Report + 1] = "F";
                                                Excel_WS1.Cells[x, Columns_Report] = "F";
                                            }
                                        }
                                        break; //中斷 不用在找了
                                    }
                                }
                                expected_log_content.Close();
                            }
                            
                            // no 19, 83   Hot Fix    
                            else if (check_report == "Hotfix") // 讀 Report 
                            {

                                string expected_log = path_expected_log;
                                string actual_log = path_actual_log;
                                System.IO.StreamReader expected_log_content = new System.IO.StreamReader(expected_log);

                                while ((line = expected_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*HOT FIX*")) //讀 expeceted.log
                                    {
                                        char key = '=';
                                        expected_verison_in_expected_log = search_in_log(line, key);
                                        //Console.WriteLine("{0}", expected_verison_expected_log); //處理版本 把 "=" 拿掉
                                        System.IO.StreamReader actual_log_content = new System.IO.StreamReader(actual_log);
                                        while ((line = actual_log_content.ReadLine()) != null)
                                        {
                                            if (line.Contains("*HOTFIX*")) //讀 actual.log
                                            {
                                                char key_test = '=';
                                                actual_verison_in_actual_log = search_in_log(line, key_test);

                                                if (actual_verison_in_actual_log == expected_verison_in_expected_log) // 比對版本
                                                {
                                                    Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report];
                                                    string comment = "Actual:" + actual_verison_in_actual_log + " Expected:" + expected_verison_in_expected_log;
                                                    add_comment.ClearComments();
                                                    //------------ Font--------------------------------------------
                                                    Excel.Comment comment1 = add_comment.AddComment(comment);
                                                    comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                    comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                    comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                    comment1.Shape.TextFrame.AutoSize = true;
                                                    //------------ Font---------------------------------------------add_comment.AddComment(comment);                                        
                                                    Excel_WS1.Cells[x, Columns_Report] = "P";

                                                    break; //中斷 不用在找了

                                                }
                                                else if (actual_verison_in_actual_log != expected_verison_in_expected_log)
                                                {
                                                    Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report];
                                                    string comment = "Actual:" + actual_verison_in_actual_log + " Expected:" + expected_verison_in_expected_log;
                                                    add_comment.ClearComments();
                                                    //------------ Font--------------------------------------------
                                                    Excel.Comment comment1 = add_comment.AddComment(comment);
                                                    comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                                    comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                                    comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                                    comment1.Shape.TextFrame.AutoSize = true;
                                                    //------------ Font---------------------------------------------add_comment.AddComment(comment);                                        
                                                    Excel_WS1.Cells[x, Columns_Report] = "F";

                                                    break; //中斷 不用在找了
                                                }
                                            }

                                        }
                                        break; //中斷 不用在找了                                       
                                    }

                                }
                                expected_log_content.Close();
                            }

                            //  Jumpstart Check  
                            else if (check_report == "Jumpstart Check") // 讀 Report 
                            {

                                string actual_log = path_actual_log;
                                System.IO.StreamReader actual_log_content = new System.IO.StreamReader(actual_log);
                                while ((line = actual_log_content.ReadLine()) != null)
                                {
                                    if (line.Contains("*Jumpstart*")) //讀 actual.log
                                    {
                                        if (line.Contains("=PASSED="))
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report];
                                            add_comment.ClearComments();
                                            Excel_WS1.Cells[x, Columns_Report] = "P";
                                        }
                                        else if (line.Contains("=FAILED="))
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report];
                                            add_comment.ClearComments();
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        else if (line.Contains("=NO RESULT="))
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report];
                                            string comment = "No result found";
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------add_comment.AddComment(comment);                                        
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }
                                        else if (line.Contains("=results_summary.txt Not Found="))
                                        {
                                            Microsoft.Office.Interop.Excel.Range add_comment = (Microsoft.Office.Interop.Excel.Range)Excel_WS1.Cells[x, Columns_Report];
                                            string comment = "results_summary.txt Not Found";
                                            add_comment.ClearComments();
                                            //------------ Font--------------------------------------------
                                            Excel.Comment comment1 = add_comment.AddComment(comment);
                                            comment1.Shape.TextFrame.Characters().Font.Name = "Calibri";
                                            comment1.Shape.TextFrame.Characters().Font.Size = 10;
                                            comment1.Shape.TextFrame.Characters().Font.FontStyle = "Bold";
                                            comment1.Shape.TextFrame.AutoSize = true;
                                            //------------ Font---------------------------------------------add_comment.AddComment(comment);                                        
                                            Excel_WS1.Cells[x, Columns_Report] = "F";
                                        }

                                        break;
                                    }
                                }
                                
                            }
                           





                        }
                    }
                    progressBar2.Value = 100;
                    label_Msg_2.Text = "Actual.log_" + Number_Actual_log + " Is Done";
                    //存檔
                    Excel_WB1.Save();
                    Excel_WB_Expect.Save();
                    //關閉及釋放物件
                    ws = null;
                    Excel_WS1 = null;
                    Excel_WS_Expect = null;

                    Excel_WB1.Close();
                    Excel_WB_Expect.Close();

                    Excel_WB1 = null;
                    Excel_WB_Expect = null;


                    Excel_APP1.Quit();
                    Excel_APP_Expected.Quit();

                    Excel_APP1 = null;
                    Excel_APP_Expected = null;
                    progressBar1.Value = 100;
                    //Console.WriteLine("");
                    //Console.WriteLine("All Completed... Press \"Enter\" to exit...");

                    //Console.Read();
                    //MessageBox.Show("All Process Completed.");
                    //Application.Exit();


                    //===========多次 report 回填
                    Number_Actual_log++;
                    path_actual_log = path_current_1 + "\\Peter_Pan_Actual_" + Number_Actual_log + ".log";

                    if (File.Exists(path_actual_log))
                    {
                        button_Start_Test_Result_Compare_Click(sender, e);
                    }
                    else
                    {
                        MessageBox.Show("All Process Completed.");
                        Application.Exit();
                    }
                    //===========多次 report 回填
                }
                else
                {
                    MessageBox.Show("Required file is not ready.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    button_Start_Test_Result_Compare.Visible = true;
                    return;
                }

            }

        }

        private void textBox_Jumpstart_TextChanged(object sender, EventArgs e)
        {
            Modified_Record_Request_Form = true;
        }

        private void textBox_HP_D1_TextChanged(object sender, EventArgs e)
        {
            Modified_Record_Request_Form = true;
        }

        private void textBox_HP_D2_TextChanged(object sender, EventArgs e)
        {
            Modified_Record_Request_Form = true;
        }

        private void textBox_HP_A1_TextChanged(object sender, EventArgs e)
        {
            Modified_Record_Request_Form = true;
        }

        private void textBox_HP_A2_TextChanged(object sender, EventArgs e)
        {
            Modified_Record_Request_Form = true;
        }

        private void textBox_HP_Hotfix_TextChanged(object sender, EventArgs e)
        {
            Modified_Record_Request_Form = true;
        }

        private void textBox_PP_D1_TextChanged(object sender, EventArgs e)
        {
            Modified_Record_Request_Form = true;
        }

        private void textBox_PP_D2_TextChanged(object sender, EventArgs e)
        {
            Modified_Record_Request_Form = true;
        }

        private void textBox_PP_A1_TextChanged(object sender, EventArgs e)
        {
            Modified_Record_Request_Form = true;
        }

        private void textBox_PP_A2_TextChanged(object sender, EventArgs e)
        {
            Modified_Record_Request_Form = true;
        }

        private void textBox_PP_Hotfix_TextChanged(object sender, EventArgs e)
        {
            Modified_Record_Request_Form = true;
        }

        private void tabControl1_Click(object sender, EventArgs e)
        {
            // Request Form
            if ((tabControl1.SelectedTab == tabPage1 || tabControl1.SelectedTab == tabPage2 || tabControl1.SelectedTab == tabPage4) && Modified_Record_Request_Form == true)
            {
                Properties.Settings set = Properties.Settings.Default;
                DialogResult dc;
                dc = MessageBox.Show("Request Form has not been saved yet.\nDo you want to save the setting ?", "Reminder", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                //tabControl1.SelectedTab = tabPage2;
                //Modified_Record = false;
                if (dc == DialogResult.Yes)
                {
                    //jumpstart
                    set.Jumpstart = textBox_Jumpstart.Text;
                    //Harry Potter
                    set.HP_Driver_Start = textBox_HP_D1.Text;
                    set.HP_Driver_End = textBox_HP_D2.Text;
                    set.HP_APP_Start = textBox_HP_A1.Text;
                    set.HP_APP_End = textBox_HP_A2.Text;
                    set.HP_Hotfix = textBox_HP_Hotfix.Text;
                    //Peter Pan
                    set.PP_Driver_Start = textBox_PP_D1.Text;
                    set.PP_Driver_End = textBox_PP_D2.Text;
                    set.PP_APP_Start = textBox_PP_A1.Text;
                    set.PP_APP_End = textBox_PP_A2.Text;
                    set.PP_Hotfix = textBox_PP_Hotfix.Text;
                    //存檔
                    set.Save();
                    Modified_Record_Request_Form = false;
                    MessageBox.Show("Save Successfully");
                }
                else if (dc == DialogResult.No)
                {
                    //Jumpstart
                    textBox_Jumpstart.Text = set.Jumpstart;

                    //Harry Potter
                    textBox_HP_D1.Text = set.HP_Driver_Start;
                    textBox_HP_D2.Text = set.HP_Driver_End;
                    textBox_HP_A1.Text = set.HP_APP_Start;
                    textBox_HP_A2.Text = set.HP_APP_End;
                    textBox_HP_Hotfix.Text = set.HP_Hotfix;

                    //Peter Pan
                    textBox_PP_D1.Text = set.PP_Driver_Start;
                    textBox_PP_D2.Text = set.PP_Driver_End;
                    textBox_PP_A1.Text = set.PP_APP_Start;
                    textBox_PP_A2.Text = set.PP_APP_End;
                    textBox_PP_Hotfix.Text = set.PP_Hotfix;

                    Modified_Record_Request_Form = false;                    
                    //return;
                }
            }
            // Spec
            else if ((tabControl1.SelectedTab == tabPage1 || tabControl1.SelectedTab == tabPage2 || tabControl1.SelectedTab == tabPage3) && Modified_Record_Spec == true)
            {
                Properties.Settings set = Properties.Settings.Default;
                DialogResult dc;
                dc = MessageBox.Show("Unit Spec has not been saved yet.\nDo you want to save the setting ?", "Reminder", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                //tabControl1.SelectedTab = tabPage2;
                //Modified_Record = false;
                if (dc == DialogResult.Yes)
                {
                    //Harry
                    set.Harry_spec_sheet = textBox_Spec_SheetName_Harry.Text;                   
                    set.Harry_spec_rows_start = textBox_Spec_rows_Harry_Start.Text;
                    set.Harry_spec_rows_end = textBox_Spec_rows_Harry_End.Text;
                    //Potter
                    set.Potter_spec_sheet = textBox_Spec_SheetName_Potter.Text;
                    set.Potter_spec_rows_start = textBox_Spec_rows_Potter_Start.Text;
                    set.Potter_spec_rows_end = textBox_Spec_rows_Potter_End.Text;
                    //Peter 
                    set.Peter_spec_sheet = textBox_Spec_SheetName_Peter.Text;
                    set.Peter_spec_rows_start = textBox_Spec_rows_Peter_Start.Text;
                    set.Peter_spec_rows_end = textBox_Spec_rows_Peter_End.Text;
                    //Pan
                    set.Pan_spec_sheet = textBox_Spec_SheetName_Pan.Text;
                    set.Pan_spec_rows_start = textBox_Spec_rows_Pan_Start.Text;
                    set.Pan_spec_rows_end = textBox_Spec_rows_Pan_End.Text;
                    //存檔
                    set.Save();
                    Modified_Record_Spec = false;
                    MessageBox.Show("Save Successfully");
                }
                else if (dc == DialogResult.No)
                {
                    //Harry
                    textBox_Spec_SheetName_Harry.Text = set.Harry_spec_sheet ;
                    textBox_Spec_rows_Harry_Start.Text = set.Harry_spec_rows_start;
                    textBox_Spec_rows_Harry_End.Text = set.Harry_spec_rows_end;
                    //Potter
                    textBox_Spec_SheetName_Potter.Text = set.Potter_spec_sheet;
                    textBox_Spec_rows_Potter_Start.Text = set.Potter_spec_rows_start;
                    textBox_Spec_rows_Potter_End.Text = set.Potter_spec_rows_end;
                    //Peter 
                    textBox_Spec_SheetName_Peter.Text = set.Peter_spec_sheet;
                    textBox_Spec_rows_Peter_Start.Text = set.Peter_spec_rows_start;
                    textBox_Spec_rows_Peter_End.Text = set.Peter_spec_rows_end;
                    //Pan
                    textBox_Spec_SheetName_Pan.Text = set.Pan_spec_sheet;
                    textBox_Spec_rows_Pan_Start.Text = set.Pan_spec_rows_start;
                    textBox_Spec_rows_Pan_End.Text = set.Pan_spec_rows_end;

                    Modified_Record_Spec = false;
                }
            }
        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void tabPage4_Click(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void groupBox7_Enter(object sender, EventArgs e)
        {

        }

        private void radioButton_ResultCompare_HP_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton_SKU_Harry_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_SKU_Harry.Checked == true)
            {
                textBox_SKU_Harry.Enabled = true;
                textBox_SKU_Potter.Enabled = false;
               
            }
        }

        private void radioButton_SKU_Potter_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_SKU_Potter.Checked == true)
            {
                textBox_SKU_Harry.Enabled = false;
                textBox_SKU_Potter.Enabled = true;
               
            }
        }

        private void radioButton_SKU_Peter_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_SKU_Peter.Checked == true)
            {
                
                textBox_SKU_Peter.Enabled = true;
                textBox_SKU_Pan.Enabled = false;
            }
        }

        private void radioButton_SKU_Pan_CheckedChanged(object sender, EventArgs e)
        {
            
            textBox_SKU_Peter.Enabled = false;
            textBox_SKU_Pan.Enabled = true;
        }

        private void textBox_Spec_rows_Harry_End_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox_Spec_SheetName_Harry_TextChanged(object sender, EventArgs e)
        {
            Modified_Record_Spec = true;
        }

        private void textBox_Spec_rows_Harry_Start_TextChanged(object sender, EventArgs e)
        {
            Modified_Record_Spec = true;
        }

        private void textBox_Spec_rows_Harry_End_TextChanged_1(object sender, EventArgs e)
        {
            Modified_Record_Spec = true;
        }

        private void textBox_Spec_SheetName_Potter_TextChanged(object sender, EventArgs e)
        {
            Modified_Record_Spec = true;
        }

        private void textBox_Spec_rows_Potter_Start_TextChanged(object sender, EventArgs e)
        {
            Modified_Record_Spec = true;
        }

        private void textBox_Spec_rows_Potter_End_TextChanged(object sender, EventArgs e)
        {
            Modified_Record_Spec = true;
        }

        private void textBox_Spec_SheetName_Peter_TextChanged(object sender, EventArgs e)
        {
            Modified_Record_Spec = true;
        }

        private void textBox_Spec_rows_Peter_Start_TextChanged(object sender, EventArgs e)
        {
            Modified_Record_Spec = true;
        }

        private void textBox_Spec_rows_Peter_End_TextChanged(object sender, EventArgs e)
        {
            Modified_Record_Spec = true;
        }

        private void textBox_Spec_SheetName_Pan_TextChanged(object sender, EventArgs e)
        {
            Modified_Record_Spec = true;
        }

        private void textBox_Spec_rows_Pan_Start_TextChanged(object sender, EventArgs e)
        {
            Modified_Record_Spec = true;
        }

        private void textBox_Spec_rows_Pan_End_TextChanged(object sender, EventArgs e)
        {
            Modified_Record_Spec = true;
        }

        private void button_Save_Spec_Click(object sender, EventArgs e)
        {
            Properties.Settings set = Properties.Settings.Default;
            DialogResult dc;
            dc = MessageBox.Show("Are you sure to save ?", "Reminder", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dc == DialogResult.Yes)
            {
                //Harry
                set.Harry_spec_sheet = textBox_Spec_SheetName_Harry.Text;
                set.Harry_spec_rows_start = textBox_Spec_rows_Harry_Start.Text;
                set.Harry_spec_rows_end = textBox_Spec_rows_Harry_End.Text;
                //Potter
                set.Potter_spec_sheet = textBox_Spec_SheetName_Potter.Text;
                set.Potter_spec_rows_start = textBox_Spec_rows_Potter_Start.Text;
                set.Potter_spec_rows_end = textBox_Spec_rows_Potter_End.Text;
                //Peter 
                set.Peter_spec_sheet = textBox_Spec_SheetName_Peter.Text;
                set.Peter_spec_rows_start = textBox_Spec_rows_Peter_Start.Text;
                set.Peter_spec_rows_end = textBox_Spec_rows_Peter_End.Text;
                //Pan
                set.Pan_spec_sheet = textBox_Spec_SheetName_Pan.Text;
                set.Pan_spec_rows_start = textBox_Spec_rows_Pan_Start.Text;
                set.Pan_spec_rows_end = textBox_Spec_rows_Pan_End.Text;
                //存檔
                set.Save();
                Modified_Record_Spec = false;
                MessageBox.Show("Save Successfully");
            }
            else if (dc == DialogResult.No)
            {
                //Harry
                textBox_Spec_SheetName_Harry.Text = set.Harry_spec_sheet;
                textBox_Spec_rows_Harry_Start.Text = set.Harry_spec_rows_start;
                textBox_Spec_rows_Harry_End.Text = set.Harry_spec_rows_end;
                //Potter
                textBox_Spec_SheetName_Potter.Text = set.Potter_spec_sheet;
                textBox_Spec_rows_Potter_Start.Text = set.Potter_spec_rows_start;
                textBox_Spec_rows_Potter_End.Text = set.Potter_spec_rows_end;
                //Peter 
                textBox_Spec_SheetName_Peter.Text = set.Peter_spec_sheet;
                textBox_Spec_rows_Peter_Start.Text = set.Peter_spec_rows_start;
                textBox_Spec_rows_Peter_End.Text = set.Peter_spec_rows_end;
                //Pan
                textBox_Spec_SheetName_Pan.Text = set.Pan_spec_sheet;
                textBox_Spec_rows_Pan_Start.Text = set.Pan_spec_rows_start;
                textBox_Spec_rows_Pan_End.Text = set.Pan_spec_rows_end;

                Modified_Record_Spec = false;
            }
        }

        private void radioButton_Actual_HP_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_Actual_HP.Checked == true)
            {
                groupBox7.Visible = true;
                groupBox8.Visible = false;
            }
            else
            {
                groupBox7.Visible = false;
                groupBox8.Visible = true;
            }
        }

        private void radioButton_SKU_Harry_CheckedChanged_1(object sender, EventArgs e)
        {

        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }
    }
}
